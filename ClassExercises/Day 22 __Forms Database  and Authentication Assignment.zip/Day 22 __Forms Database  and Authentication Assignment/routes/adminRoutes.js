const express = require("express");
const { getAdminDashboard } = require("../controllers/adminController");
const { ensureAuthenticated, ensureAdmin } = require("../middlewares/authMiddleware");

const router = express.Router();

router.get("/admin", ensureAuthenticated, ensureAdmin, getAdminDashboard);

module.exports = router;
