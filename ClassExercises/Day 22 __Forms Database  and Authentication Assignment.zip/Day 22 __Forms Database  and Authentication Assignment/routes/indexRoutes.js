const express = require("express");
const { getHome } = require("../controllers/pageController");

const router = express.Router();

router.get("/", getHome);

module.exports = router;
