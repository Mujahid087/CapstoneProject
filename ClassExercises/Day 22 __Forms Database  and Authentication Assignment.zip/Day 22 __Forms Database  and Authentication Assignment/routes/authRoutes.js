const express = require("express");
const {
  getRegisterForm,
  getLoginForm,
} = require("../controllers/pageController");
const { register, login, logout } = require("../controllers/authController");

const router = express.Router();

router.get("/register", getRegisterForm);
router.post("/register", register);
router.get("/login", getLoginForm);
router.post("/login", login);
router.get("/logout", logout);

module.exports = router;
