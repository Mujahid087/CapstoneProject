function validateRegistration({ fullName, email, password }) {
  if (!fullName || !email || !password) {
    return "All fields are required.";
  }

  if (fullName.trim().length < 3) {
    return "Full name must be at least 3 characters.";
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return "Invalid email format.";
  }

  if (password.length < 6) {
    return "Password must be at least 6 characters.";
  }

  return null;
}

module.exports = { validateRegistration };
