require("dotenv").config({ quiet: true });

const express = require("express");
const path = require("path");
const bodyParser = require("body-parser");
const { connectDatabase } = require("./config/db");
const { createSessionMiddleware } = require("./config/session");
const { passport, configurePassport } = require("./config/passport");
const indexRoutes = require("./routes/indexRoutes");
const authRoutes = require("./routes/authRoutes");
const adminRoutes = require("./routes/adminRoutes");

const app = express();
const PORT = process.env.PORT || 3000;
const MONGO_URI =
  process.env.MONGO_URI || "mongodb://127.0.0.1:27017/day22_assignment_db";
const SESSION_SECRET = process.env.SESSION_SECRET || "replace-me-in-env";

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, "public")));

app.use(
  createSessionMiddleware({
    mongoUri: MONGO_URI,
    sessionSecret: SESSION_SECRET,
  })
);

configurePassport();
app.use(passport.initialize());
app.use(passport.session());

app.use(indexRoutes);
app.use(authRoutes);
app.use(adminRoutes);

app.use((error, _req, res, _next) => {
  console.error("Unhandled error:", error.message);
  res.status(500).send("Internal server error.");
});

connectDatabase(MONGO_URI).then(() => {
  app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
});
