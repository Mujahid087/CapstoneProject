function getAdminDashboard(_req, res) {
  res.send("Welcome, Admin!");
}

module.exports = { getAdminDashboard };
