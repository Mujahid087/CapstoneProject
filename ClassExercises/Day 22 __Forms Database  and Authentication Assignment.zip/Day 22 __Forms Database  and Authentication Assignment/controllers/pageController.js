function renderPage(title, body) {
  return `
    <!doctype html>
    <html lang="en">
      <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>${title}</title>
        <link rel="stylesheet" href="/css/style.css" />
      </head>
      <body>
        <main class="container">
          ${body}
        </main>
      </body>
    </html>
  `;
}

function getHome(_req, res) {
  const content = `
    <section class="card">
      <h1>Day 22 Assignment</h1>
      <p class="subtitle">Forms, Database, and Authentication</p>
      <div class="actions">
        <a class="btn" href="/register">Go to Register</a>
        <a class="btn btn-secondary" href="/login">Go to Login</a>
      </div>
    </section>
  `;
  res.send(renderPage("Home", content));
}

function getRegisterForm(_req, res) {
  const content = `
    <section class="card">
      <h2>Register</h2>
      <form method="POST" action="/register" class="form">
        <label for="fullName">Full Name</label>
        <input id="fullName" name="fullName" type="text" required />

        <label for="email">Email</label>
        <input id="email" name="email" type="email" required />

        <label for="password">Password</label>
        <input id="password" name="password" type="password" required />

        <label for="role">Role</label>
        <select id="role" name="role">
          <option value="user">user</option>
          <option value="admin">admin</option>
        </select>

        <button type="submit" class="btn">Register</button>
      </form>
      <p class="footnote">Already have an account? <a href="/login">Login</a></p>
    </section>
  `;
  res.send(renderPage("Register", content));
}

function getLoginForm(_req, res) {
  const content = `
    <section class="card">
      <h2>Login</h2>
      <form method="POST" action="/login" class="form">
        <label for="email">Email</label>
        <input id="email" name="email" type="email" required />

        <label for="password">Password</label>
        <input id="password" name="password" type="password" required />

        <button type="submit" class="btn">Login</button>
      </form>
      <p class="footnote">No account yet? <a href="/register">Register</a></p>
    </section>
  `;
  res.send(renderPage("Login", content));
}

module.exports = {
  getHome,
  getRegisterForm,
  getLoginForm,
};
