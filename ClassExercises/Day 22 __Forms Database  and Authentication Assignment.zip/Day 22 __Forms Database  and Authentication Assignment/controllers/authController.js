const bcrypt = require("bcrypt");
const { passport } = require("../config/passport");
const User = require("../models/User");
const { validateRegistration } = require("../utils/validation");

async function register(req, res) {
  try {
    const { fullName, email, password, role } = req.body;
    const validationError = validateRegistration({ fullName, email, password });

    if (validationError) {
      return res.status(400).send(validationError);
    }

    const normalizedEmail = email.toLowerCase().trim();
    const existingUser = await User.findOne({ email: normalizedEmail });
    if (existingUser) {
      return res.status(409).send("Email already registered.");
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = await User.create({
      fullName: fullName.trim(),
      email: normalizedEmail,
      password: hashedPassword,
      role: role === "admin" ? "admin" : "user",
    });

    console.log("Data saved to users collection:", {
      id: newUser._id.toString(),
      fullName: newUser.fullName,
      email: newUser.email,
      role: newUser.role,
    });

    return res.send(`Registration successful for ${newUser.fullName}`);
  } catch (error) {
    console.error("Registration error:", error.message);
    return res.status(500).send("Server error during registration.");
  }
}

function login(req, res, next) {
  passport.authenticate("local", (error, user, info) => {
    if (error) {
      return next(error);
    }

    if (!user) {
      return res.status(401).send(info?.message || "Login failed");
    }

    return req.logIn(user, (loginError) => {
      if (loginError) {
        return next(loginError);
      }
      return res.send(`Logged in as ${user.fullName} (${user.role})`);
    });
  })(req, res, next);
}

function logout(req, res, next) {
  req.logout((error) => {
    if (error) {
      return next(error);
    }
    req.session.destroy(() => res.send("Logged out"));
  });
}

module.exports = { register, login, logout };
