const session = require("express-session");
const MongoStore = require("connect-mongo").default;

function createSessionMiddleware({ mongoUri, sessionSecret }) {
  const sessionOptions = {
    secret: sessionSecret,
    resave: false,
    saveUninitialized: false,
    cookie: { maxAge: 1000 * 60 * 60 },
    store: MongoStore.create({ mongoUrl: mongoUri }),
  };

  return session(sessionOptions);
}

module.exports = { createSessionMiddleware };
