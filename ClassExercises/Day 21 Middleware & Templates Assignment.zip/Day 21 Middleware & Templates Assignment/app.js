const express = require("express");
const path = require("path");

const app = express();
const PORT = 3000;

app.use((req, res, next) => {
  const timestamp = new Date().toISOString();
  console.log(`[${req.method}] ${req.url} at ${timestamp}`);
  next();
});

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

const courses = [
  { id: 1, title: "Introduction to JavaScript", duration: "4 weeks" },
  { id: 2, title: "Node.js Fundamentals", duration: "3 weeks" },
  { id: 3, title: "React for Beginners", duration: "5 weeks" },
  { id: 4, title: "Express.js Masterclass", duration: "3 weeks" },
  { id: 5, title: "MongoDB Essentials", duration: "2 weeks" }
];

const users = [];

app.get("/", (req, res) => {
  res.json({ message: "Welcome to SkillSphere LMS" });
});

app.get("/courses", (req, res) => {
  res.render("courses", { courses });
});

app.get("/users", (req, res) => {
  res.json(users);
});

app.post("/users", (req, res) => {
  const userData = req.body;
  users.push(userData);
  res.status(201).json({
    message: "User created successfully",
    data: userData
  });
});

app.listen(PORT, () => {
  console.log(`SkillSphere LMS server running on http://localhost:${PORT}`);
});
