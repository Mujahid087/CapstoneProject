import { BrowserRouter, Routes, Route, NavLink } from 'react-router-dom';
import { Provider } from 'react-redux';
import { ThemeProvider } from './context/ThemeContext';
import store from './store/store';
import OfflineBanner from './components/OfflineBanner';
import ThemeToggle from './components/ThemeToggle';

import HomePage from './pages/HomePage';
import ThemePage from './pages/ThemePage';
import PWAPage from './pages/PWAPage';
import WorkoutTracker from './pages/WorkoutTracker';
import ProductDashboard from './pages/ProductDashboard';

import './App.css';

export default function App() {
  return (
    <Provider store={store}>
      <ThemeProvider>
        <BrowserRouter>
          <div className="app">
            <nav className="navbar">
              <div className="nav-brand">
                <NavLink to="/" className="brand-link">
                  ⚛️ <span>Day 15</span>
                </NavLink>
              </div>
              <div className="nav-links">
                <NavLink to="/theme" className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}>
                  🎨 Theme
                </NavLink>
                <NavLink to="/pwa" className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}>
                  📱 PWA
                </NavLink>
                <NavLink to="/workout" className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}>
                  💪 Workout
                </NavLink>
                <NavLink to="/products" className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}>
                  🛍️ Products
                </NavLink>
              </div>
              <div className="nav-toggle">
                <ThemeToggle />
              </div>
            </nav>

            <main className="main-content">
              <Routes>
                <Route path="/" element={<HomePage />} />
                <Route path="/theme" element={<ThemePage />} />
                <Route path="/pwa" element={<PWAPage />} />
                <Route path="/workout" element={<WorkoutTracker />} />
                <Route path="/products" element={<ProductDashboard />} />
              </Routes>
            </main>

            <footer className="footer">
              <p>Day 15 — React Hooks &amp; State Management © 2026</p>
            </footer>

            <OfflineBanner />
          </div>
        </BrowserRouter>
      </ThemeProvider>
    </Provider>
  );
}
