import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';


const mockProducts = [
  { id: 1, name: 'Wireless Headphones', price: 79.99, category: 'Electronics', stock: 45 },
  { id: 2, name: 'Running Shoes', price: 129.99, category: 'Sports', stock: 30 },
  { id: 3, name: 'Coffee Maker', price: 49.99, category: 'Kitchen', stock: 60 },
  { id: 4, name: 'Yoga Mat', price: 29.99, category: 'Sports', stock: 100 },
  { id: 5, name: 'Mechanical Keyboard', price: 149.99, category: 'Electronics', stock: 25 },
  { id: 6, name: 'Water Bottle', price: 19.99, category: 'Kitchen', stock: 200 },
];


export const fetchProducts = createAsyncThunk('products/fetchProducts', async () => {
  return new Promise((resolve) => {
    setTimeout(() => resolve(mockProducts), 800);
  });
});

const productsSlice = createSlice({
  name: 'products',
  initialState: {
    items: [],
    status: 'idle',
    error: null,
  },
  reducers: {
    updateProduct(state, action) {
      const { id, changes } = action.payload;
      const existing = state.items.find((p) => p.id === id);
      if (existing) Object.assign(existing, changes);
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchProducts.pending, (state) => {
        state.status = 'loading';
      })
      .addCase(fetchProducts.fulfilled, (state, action) => {
        state.status = 'succeeded';
        state.items = action.payload;
      })
      .addCase(fetchProducts.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.error.message;
      });
  },
});

export const { updateProduct } = productsSlice.actions;
export default productsSlice.reducer;
