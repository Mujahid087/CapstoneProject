import { useEffect, useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { fetchProducts, updateProduct } from '../store/productsSlice';

export default function ProductDashboard() {
    const dispatch = useDispatch();
    const { items: products, status, error } = useSelector((state) => state.products);
    const [editingId, setEditingId] = useState(null);
    const [editForm, setEditForm] = useState({ name: '', price: '', stock: '' });

    useEffect(() => {
        if (status === 'idle') {
            dispatch(fetchProducts());
        }
    }, [status, dispatch]);

    const startEdit = (product) => {
        setEditingId(product.id);
        setEditForm({
            name: product.name,
            price: product.price,
            stock: product.stock,
        });
    };

    const cancelEdit = () => {
        setEditingId(null);
        setEditForm({ name: '', price: '', stock: '' });
    };

    const saveEdit = (id) => {
        dispatch(
            updateProduct({
                id,
                changes: {
                    name: editForm.name,
                    price: parseFloat(editForm.price),
                    stock: parseInt(editForm.stock),
                },
            })
        );
        setEditingId(null);
    };

    return (
        <div className="page products-page">
            <div className="page-header">
                <h1>🛍️ Product Dashboard</h1>
                <p className="subtitle">Challenge 8: Redux Toolkit (configureStore, createSlice, useSelector)</p>
            </div>

            {status === 'loading' && (
                <div className="loading-state">
                    <div className="spinner"></div>
                    <p>Fetching products from API…</p>
                </div>
            )}

            {status === 'failed' && (
                <div className="card glass-card error-card">
                    <p>❌ Error: {error}</p>
                    <button className="btn btn-accent" onClick={() => dispatch(fetchProducts())}>
                        Retry
                    </button>
                </div>
            )}

            {status === 'succeeded' && (
                <>
                    <div className="product-stats">
                        <div className="card glass-card mini-stat">
                            <span className="stat-value">{products.length}</span>
                            <span className="stat-label">Products</span>
                        </div>
                        <div className="card glass-card mini-stat">
                            <span className="stat-value">
                                ${products.reduce((s, p) => s + p.price, 0).toFixed(2)}
                            </span>
                            <span className="stat-label">Total Value</span>
                        </div>
                        <div className="card glass-card mini-stat">
                            <span className="stat-value">
                                {products.reduce((s, p) => s + p.stock, 0)}
                            </span>
                            <span className="stat-label">Total Stock</span>
                        </div>
                    </div>

                    <div className="card glass-card">
                        <div className="table-wrapper">
                            <table className="data-table">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Product</th>
                                        <th>Category</th>
                                        <th>Price</th>
                                        <th>Stock</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {products.map((product) => (
                                        <tr key={product.id}>
                                            <td>#{product.id}</td>
                                            <td>
                                                {editingId === product.id ? (
                                                    <input
                                                        className="input inline-input"
                                                        value={editForm.name}
                                                        onChange={(e) =>
                                                            setEditForm({ ...editForm, name: e.target.value })
                                                        }
                                                    />
                                                ) : (
                                                    product.name
                                                )}
                                            </td>
                                            <td>
                                                <span className="category-badge">{product.category}</span>
                                            </td>
                                            <td>
                                                {editingId === product.id ? (
                                                    <input
                                                        className="input inline-input small"
                                                        type="number"
                                                        value={editForm.price}
                                                        onChange={(e) =>
                                                            setEditForm({ ...editForm, price: e.target.value })
                                                        }
                                                    />
                                                ) : (
                                                    `$${product.price.toFixed(2)}`
                                                )}
                                            </td>
                                            <td>
                                                {editingId === product.id ? (
                                                    <input
                                                        className="input inline-input small"
                                                        type="number"
                                                        value={editForm.stock}
                                                        onChange={(e) =>
                                                            setEditForm({ ...editForm, stock: e.target.value })
                                                        }
                                                    />
                                                ) : (
                                                    product.stock
                                                )}
                                            </td>
                                            <td>
                                                {editingId === product.id ? (
                                                    <div className="action-btns">
                                                        <button
                                                            className="btn btn-success btn-sm"
                                                            onClick={() => saveEdit(product.id)}
                                                        >
                                                            ✓
                                                        </button>
                                                        <button
                                                            className="btn btn-secondary btn-sm"
                                                            onClick={cancelEdit}
                                                        >
                                                            ✕
                                                        </button>
                                                    </div>
                                                ) : (
                                                    <button
                                                        className="btn btn-accent btn-sm"
                                                        onClick={() => startEdit(product)}
                                                    >
                                                        ✏️ Edit
                                                    </button>
                                                )}
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </>
            )}
        </div>
    );
}
