import { useTheme } from '../context/ThemeContext';
import ThemeToggle from '../components/ThemeToggle';

export default function ThemePage() {
    const { theme } = useTheme();

    return (
        <div className="page theme-page">
            <div className="page-header">
                <h1>🎨 Theme Settings</h1>
                <p className="subtitle">Challenge 5: React Context API</p>
            </div>

            <div className="card glass-card theme-demo-card">
                <h2>Current Theme</h2>
                <div className="theme-badge">
                    <span className={`badge ${theme}`}>
                        {theme === 'light' ? '☀️ Light Mode' : '🌙 Dark Mode'}
                    </span>
                </div>
                <p className="info-text">
                    Your theme preference is persisted in <code>localStorage</code> and
                    will be remembered on your next visit.
                </p>
                <ThemeToggle />
            </div>
        </div>
    );
}
