export default function PWAPage() {
    return (
        <div className="page pwa-page">
            <div className="page-header">
                <h1>📱 Progressive Web App</h1>
                <p className="subtitle">Challenge 6: Service Worker &amp; Manifest</p>
            </div>

            <div className="card glass-card">
                <h2>✅ PWA Features Enabled</h2>
                <div className="pwa-features">
                    <div className="pwa-feature">
                        <span className="pwa-icon">📄</span>
                        <div>
                            <strong>Web App Manifest</strong>
                            <p><code>manifest.json</code> linked in <code>index.html</code> with app name, icons, theme color, and standalone display mode.</p>
                        </div>
                    </div>
                    <div className="pwa-feature">
                        <span className="pwa-icon">⚙️</span>
                        <div>
                            <strong>Service Worker</strong>
                            <p>Registered in <code>main.jsx</code>. Caches app shell on install and serves cached assets on fetch (cache-first strategy).</p>
                        </div>
                    </div>
                    <div className="pwa-feature">
                        <span className="pwa-icon">📶</span>
                        <div>
                            <strong>Offline Banner</strong>
                            <p>An offline indicator banner appears at the bottom when network connectivity is lost. Try turning off your WiFi!</p>
                        </div>
                    </div>
                    <div className="pwa-feature">
                        <span className="pwa-icon">📥</span>
                        <div>
                            <strong>Installable</strong>
                            <p>The app can be installed from the browser's address bar or the &quot;Install App&quot; prompt.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
