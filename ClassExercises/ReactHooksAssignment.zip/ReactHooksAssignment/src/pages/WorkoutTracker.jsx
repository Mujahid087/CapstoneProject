import { useState, useCallback } from 'react';
import useTimer from '../hooks/useTimer';

function formatTime(totalSeconds) {
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

export default function WorkoutTracker() {
    const { seconds, isRunning, start, stop, reset } = useTimer(0);
    const [sets, setSets] = useState([]);
    const [exerciseName, setExerciseName] = useState('');
    const [reps, setReps] = useState('');
    const [restMode, setRestMode] = useState(false);
    const { seconds: restSeconds, isRunning: restRunning, start: startRest, stop: stopRest, reset: resetRest } = useTimer(0);

    const REST_DURATION = 30; // seconds

    const logSet = useCallback(() => {
        if (!exerciseName.trim()) return;
        const newSet = {
            id: Date.now(),
            exercise: exerciseName,
            reps: parseInt(reps) || 0,
            duration: seconds,
            timestamp: new Date().toLocaleTimeString(),
        };
        setSets((prev) => [newSet, ...prev]);
        reset();
        setReps('');
        // Start rest timer
        resetRest();
        setRestMode(true);
        startRest();
    }, [exerciseName, reps, seconds, reset, resetRest, startRest]);

    // Auto-stop rest when REST_DURATION reached
    if (restRunning && restSeconds >= REST_DURATION && restMode) {
        stopRest();
        resetRest();
        setRestMode(false);
    }

    const skipRest = () => {
        stopRest();
        resetRest();
        setRestMode(false);
    };

    const totalReps = sets.reduce((sum, s) => sum + s.reps, 0);
    const totalTime = sets.reduce((sum, s) => sum + s.duration, 0);

    return (
        <div className="page workout-page">
            <div className="page-header">
                <h1>💪 Workout Tracker</h1>
                <p className="subtitle">Challenge 7: React Hooks (useState, useEffect, useRef)</p>
            </div>

            {/* Rest Mode Overlay */}
            {restMode && (
                <div className="rest-overlay">
                    <div className="rest-content card glass-card">
                        <h2>⏸️ Rest Period</h2>
                        <div className="timer-display rest-timer">
                            {formatTime(REST_DURATION - restSeconds)}
                        </div>
                        <p>Take a breather before your next set!</p>
                        <button className="btn btn-accent" onClick={skipRest}>
                            Skip Rest →
                        </button>
                    </div>
                </div>
            )}

            <div className="workout-grid">
                {/* Timer Card */}
                <div className="card glass-card timer-card">
                    <h2>⏱️ Set Timer</h2>
                    <div className="timer-display">{formatTime(seconds)}</div>
                    <div className="timer-controls">
                        {!isRunning ? (
                            <button id="start-timer-btn" className="btn btn-success" onClick={start}>
                                ▶ Start
                            </button>
                        ) : (
                            <button id="stop-timer-btn" className="btn btn-danger" onClick={stop}>
                                ⏸ Pause
                            </button>
                        )}
                        <button id="reset-timer-btn" className="btn btn-secondary" onClick={reset}>
                            ↺ Reset
                        </button>
                    </div>
                </div>

                {/* Log Set Card */}
                <div className="card glass-card log-card">
                    <h2>📝 Log Set</h2>
                    <div className="form-group">
                        <label htmlFor="exercise-name">Exercise</label>
                        <input
                            id="exercise-name"
                            type="text"
                            placeholder="e.g. Push-ups"
                            value={exerciseName}
                            onChange={(e) => setExerciseName(e.target.value)}
                            className="input"
                        />
                    </div>
                    <div className="form-group">
                        <label htmlFor="rep-count">Reps</label>
                        <input
                            id="rep-count"
                            type="number"
                            placeholder="12"
                            value={reps}
                            onChange={(e) => setReps(e.target.value)}
                            className="input"
                            min="0"
                        />
                    </div>
                    <button
                        id="log-set-btn"
                        className="btn btn-accent full-width"
                        onClick={logSet}
                        disabled={!exerciseName.trim()}
                    >
                        ✓ Log Set ({formatTime(seconds)})
                    </button>
                </div>

                {/* Stats Card */}
                <div className="card glass-card stats-card">
                    <h2>📊 Session Stats</h2>
                    <div className="stats-grid">
                        <div className="stat">
                            <span className="stat-value">{sets.length}</span>
                            <span className="stat-label">Sets</span>
                        </div>
                        <div className="stat">
                            <span className="stat-value">{totalReps}</span>
                            <span className="stat-label">Total Reps</span>
                        </div>
                        <div className="stat">
                            <span className="stat-value">{formatTime(totalTime)}</span>
                            <span className="stat-label">Total Time</span>
                        </div>
                    </div>
                </div>
            </div>

            {/* Set History */}
            <div className="card glass-card history-card">
                <h2>📋 Set History</h2>
                {sets.length === 0 ? (
                    <p className="empty-state">No sets logged yet. Start your workout!</p>
                ) : (
                    <div className="table-wrapper">
                        <table className="data-table">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Exercise</th>
                                    <th>Reps</th>
                                    <th>Duration</th>
                                    <th>Time</th>
                                </tr>
                            </thead>
                            <tbody>
                                {sets.map((set, idx) => (
                                    <tr key={set.id}>
                                        <td>{sets.length - idx}</td>
                                        <td>{set.exercise}</td>
                                        <td>{set.reps}</td>
                                        <td>{formatTime(set.duration)}</td>
                                        <td>{set.timestamp}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}
            </div>
        </div>
    );
}
