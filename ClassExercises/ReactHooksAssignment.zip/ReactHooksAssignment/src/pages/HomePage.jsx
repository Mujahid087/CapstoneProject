import { Link } from 'react-router-dom';
import { useTheme } from '../context/ThemeContext';
import ThemeToggle from '../components/ThemeToggle';

export default function HomePage() {
    const { theme } = useTheme();

    const challenges = [
        {
            id: 5,
            title: 'React Context API',
            icon: '🎨',
            description: 'Theme toggle with localStorage persistence using createContext & useContext.',
            path: '/theme',
            tags: ['Context API', 'useContext', 'localStorage'],
        },
        {
            id: 6,
            title: 'Progressive Web App',
            icon: '📱',
            description: 'PWA with service worker, manifest.json, and offline banner.',
            path: '/pwa',
            tags: ['Service Worker', 'manifest.json', 'Offline'],
        },
        {
            id: 7,
            title: 'Workout Tracker',
            icon: '💪',
            description: 'Track sets, reps, and rest time with useState, useEffect, useRef & custom hooks.',
            path: '/workout',
            tags: ['useState', 'useEffect', 'useRef', 'Custom Hook'],
        },
        {
            id: 8,
            title: 'Product Dashboard',
            icon: '🛍️',
            description: 'Global state management with Redux Toolkit, createSlice, and async thunks.',
            path: '/products',
            tags: ['Redux Toolkit', 'createSlice', 'redux-thunk'],
        },
    ];

    return (
        <div className="page home-page">
            <div className="hero">
                <div className="hero-content">
                    <h1 className="hero-title">
                        Day 15 <span className="gradient-text">React Hooks</span> &amp; State Management
                    </h1>
                    <p className="hero-subtitle">
                        Four challenges demonstrating Context API, PWA, React Hooks, and Redux Toolkit
                    </p>
                    <div className="hero-actions">
                        <ThemeToggle />
                    </div>
                </div>
                <div className="hero-glow"></div>
            </div>

            <div className="challenges-grid">
                {challenges.map((c) => (
                    <Link to={c.path} key={c.id} className="challenge-card card glass-card">
                        <div className="challenge-icon">{c.icon}</div>
                        <div className="challenge-number">Challenge {c.id}</div>
                        <h2>{c.title}</h2>
                        <p>{c.description}</p>
                        <div className="tag-list">
                            {c.tags.map((tag) => (
                                <span className="tag" key={tag}>{tag}</span>
                            ))}
                        </div>
                        <span className="card-arrow">→</span>
                    </Link>
                ))}
            </div>
        </div>
    );
}
