import { useTheme } from '../context/ThemeContext';
import './ThemeToggle.css';

export default function ThemeToggle() {
    const { theme, toggleTheme } = useTheme();

    return (
        <button
            id="theme-toggle-btn"
            className={`theme-toggle ${theme}`}
            onClick={toggleTheme}
            aria-label={`Switch to ${theme === 'light' ? 'dark' : 'light'} mode`}
        >
            <span className="toggle-icon">{theme === 'light' ? '🌙' : '☀️'}</span>
            <span className="toggle-label">{theme === 'light' ? 'Dark Mode' : 'Light Mode'}</span>
        </button>
    );
}
