import React from 'react';
import AddBookForm from '../components/AddBookForm.jsx';

function AddBookPage() {
    return (
        <div className="page add-book-page">
            <AddBookForm />
        </div>
    );
}

export default AddBookPage;
