import React from 'react';
import BookList from '../components/BookList.jsx';

function HomePage() {
    return (
        <div className="page home-page">
            <header className="page-header">
                <h1>Welcome to BookVerse</h1>
                <p className="page-description">
                    Your personal book collection manager. Add new books and see them appear instantly.
                </p>
            </header>

            <BookList />
        </div>
    );
}

export default HomePage;
