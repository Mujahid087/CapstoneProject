export const ActionTypes = {
  ADD_BOOK: 'ADD_BOOK',
};

export function addBook(dispatcher, bookData) {
  const action = {
    type: ActionTypes.ADD_BOOK,
    payload: {
      id: Date.now(),
      title: bookData.title,
      author: bookData.author,
      price: parseFloat(bookData.price),
    },
  };

  dispatcher.dispatch(action);
}
