import { ActionTypes } from './actions.js';

class BookStore {
  constructor(dispatcher) {
    this._books = [
      { id: 1, title: 'The Great Gatsby', author: 'F. Scott Fitzgerald', price: 10.99 },
      { id: 2, title: 'To Kill a Mockingbird', author: 'Harper Lee', price: 12.50 },
      { id: 3, title: '1984', author: 'George Orwell', price: 9.99 },
    ];

    this._listeners = [];

    dispatcher.register((action) => {
      switch (action.type) {
        case ActionTypes.ADD_BOOK:
          this._books = [...this._books, action.payload];
          this._emitChange();
          break;
        default:
          break;
      }
    });
  }

  getBooks() {
    return [...this._books];
  }

  addChangeListener(callback) {
    this._listeners.push(callback);
  }

  removeChangeListener(callback) {
    this._listeners = this._listeners.filter((listener) => listener !== callback);
  }

  _emitChange() {
    this._listeners.forEach((listener) => listener());
  }
}

export default BookStore;
