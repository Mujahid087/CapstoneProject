import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar.jsx';
import HomePage from './pages/HomePage.jsx';
import AddBookPage from './pages/AddBookPage.jsx';

function App() {
    return (
        <BrowserRouter>
            <div className="app">
                <Navbar />
                <main className="main-content">
                    <Routes>
                        <Route path="/" element={<HomePage />} />
                        <Route path="/add-book" element={<AddBookPage />} />
                    </Routes>
                </main>
                <footer className="footer">
                    <p>BookVerse © 2026 — Built with React, Formik, Yup & Flux Architecture</p>
                </footer>
            </div>
        </BrowserRouter>
    );
}

export default App;
