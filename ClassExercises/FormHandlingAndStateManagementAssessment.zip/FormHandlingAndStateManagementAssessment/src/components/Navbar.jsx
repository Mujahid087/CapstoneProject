import React from 'react';
import { Link, useLocation } from 'react-router-dom';

function Navbar() {
    const location = useLocation();

    return (
        <nav className="navbar">
            <div className="navbar-brand">
                <Link to="/">
                    <span className="brand-icon">📚</span>
                    <span className="brand-text">BookVerse</span>
                </Link>
            </div>
            <div className="navbar-links">
                <Link
                    to="/"
                    className={`nav-link ${location.pathname === '/' ? 'active' : ''}`}
                >
                    Home
                </Link>
                <Link
                    to="/add-book"
                    className={`nav-link ${location.pathname === '/add-book' ? 'active' : ''}`}
                >
                    + Add Book
                </Link>
            </div>
        </nav>
    );
}

export default Navbar;
