import React, { useState, useEffect } from 'react';
import BookCard from './BookCard.jsx';
import container from '../di/container.js';

function BookList() {
    const bookStore = container.resolve('bookStore');
    const [books, setBooks] = useState(bookStore.getBooks());

    useEffect(() => {
        const handleStoreChange = () => {
            setBooks(bookStore.getBooks());
        };

        bookStore.addChangeListener(handleStoreChange);

        return () => {
            bookStore.removeChangeListener(handleStoreChange);
        };
    }, [bookStore]);

    return (
        <div className="book-list">
            <h2 className="section-title">📖 Book Collection</h2>
            <p className="section-subtitle">
                {books.length} book{books.length !== 1 ? 's' : ''} in the collection
            </p>
            <div className="book-grid">
                {books.map((book) => (
                    <BookCard key={book.id} book={book} />
                ))}
            </div>
        </div>
    );
}

export default BookList;
