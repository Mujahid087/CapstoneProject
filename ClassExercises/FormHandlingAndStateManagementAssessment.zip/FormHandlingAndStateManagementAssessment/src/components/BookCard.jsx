import React from 'react';

function BookCard({ book }) {
    return (
        <div className="book-card">
            <div className="book-card-spine"></div>
            <div className="book-card-content">
                <h3 className="book-title">{book.title}</h3>
                <p className="book-author">by {book.author}</p>
                <p className="book-price">${book.price.toFixed(2)}</p>
            </div>
        </div>
    );
}

export default BookCard;
