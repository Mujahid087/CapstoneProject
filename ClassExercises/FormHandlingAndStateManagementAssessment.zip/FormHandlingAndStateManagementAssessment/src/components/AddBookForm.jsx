import React, { useState } from 'react';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import { useNavigate } from 'react-router-dom';
import { addBook } from '../flux/actions.js';
import container from '../di/container.js';

const validationSchema = Yup.object({
    title: Yup.string()
        .required('Title is required')
        .min(2, 'Title must be at least 2 characters'),
    author: Yup.string()
        .required('Author is required')
        .min(2, 'Author must be at least 2 characters'),
    price: Yup.number()
        .required('Price is required')
        .positive('Price must be a positive number')
        .typeError('Price must be a valid number'),
});

function AddBookForm() {
    const navigate = useNavigate();
    const [successMessage, setSuccessMessage] = useState('');

    const dispatcher = container.resolve('dispatcher');

    const handleSubmit = (values, { resetForm }) => {
        addBook(dispatcher, values);

        setSuccessMessage(`"${values.title}" has been added to the collection!`);
        resetForm();

        setTimeout(() => {
            navigate('/');
        }, 1500);
    };

    return (
        <div className="form-container">
            <h2 className="form-title">📝 Add a New Book</h2>
            <p className="form-subtitle">
                Fill in the details below to add a book to the collection.
            </p>

            {successMessage && (
                <div className="success-message">{successMessage}</div>
            )}

            <Formik
                initialValues={{ title: '', author: '', price: '' }}
                validationSchema={validationSchema}
                onSubmit={handleSubmit}
            >
                {({ isSubmitting, touched, errors }) => (
                    <Form className="book-form" noValidate>
                        <div className="form-group">
                            <label htmlFor="title" className="form-label">
                                Book Title
                            </label>
                            <Field
                                type="text"
                                name="title"
                                id="title"
                                className={`form-input ${touched.title && errors.title ? 'input-error' : ''}`}
                                placeholder="e.g. The Great Gatsby"
                            />
                            <ErrorMessage name="title" component="div" className="error-text" />
                        </div>

                        <div className="form-group">
                            <label htmlFor="author" className="form-label">
                                Author
                            </label>
                            <Field
                                type="text"
                                name="author"
                                id="author"
                                className={`form-input ${touched.author && errors.author ? 'input-error' : ''}`}
                                placeholder="e.g. F. Scott Fitzgerald"
                            />
                            <ErrorMessage name="author" component="div" className="error-text" />
                        </div>

                        <div className="form-group">
                            <label htmlFor="price" className="form-label">
                                Price ($)
                            </label>
                            <Field
                                type="number"
                                name="price"
                                id="price"
                                className={`form-input ${touched.price && errors.price ? 'input-error' : ''}`}
                                placeholder="e.g. 12.99"
                                step="0.01"
                            />
                            <ErrorMessage name="price" component="div" className="error-text" />
                        </div>

                        <button
                            type="submit"
                            className="submit-btn"
                            disabled={isSubmitting}
                        >
                            {isSubmitting ? 'Adding...' : 'Add Book'}
                        </button>
                    </Form>
                )}
            </Formik>
        </div>
    );
}

export default AddBookForm;
