import AppDispatcher from '../flux/dispatcher.js';
import BookStore from '../flux/bookStore.js';

class DIContainer {
  constructor() {
    this._services = {};
  }

  register(name, instance) {
    this._services[name] = instance;
  }

  resolve(name) {
    const service = this._services[name];
    if (!service) {
      throw new Error(`Service "${name}" is not registered in the DI container.`);
    }
    return service;
  }
}

const container = new DIContainer();

container.register('dispatcher', AppDispatcher);
container.register('bookStore', new BookStore(AppDispatcher));

export default container;
