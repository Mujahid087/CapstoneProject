# Day 26 - Database Connectivity

This project implements all three SkillSphere Day 26 challenges with a clean Node.js structure.

## Folder Structure

```text
src/
  config/        Environment and database configuration
  db/            Connection helpers and migrations
  models/        Mongoose and Sequelize models
  scripts/       Executable assignment scripts
  services/      Business logic for each challenge
data/            Local SQLite database file for Sequelize demo
```

## Setup

1. Install dependencies:

```bash
npm install
```

2. Copy `.env.example` to `.env` and update the credentials.

3. Make sure:
   - MySQL is running and the `skillsphere` database exists.
   - MongoDB is running and reachable from `MONGODB_URI`.

## Run Challenges

### 1. MySQL Integration

```bash
npm run mysql:insert
```

Expected behavior:
- Creates the `courses` table if needed
- Inserts a sample course
- Prints a console confirmation

### 2. MongoDB Integration

```bash
npm run mongo:fetch
```

Expected behavior:
- Connects with Mongoose
- Seeds sample `User` and `Enrollment` data when collections are empty
- Fetches and displays enrollment details

### 3. Sequelize ORM

```bash
npm run sequelize:demo
```

Expected behavior:
- Defines `Instructor` and `Course` models
- Applies a one-to-many relationship
- Seeds sample data
- Retrieves all courses for an instructor

## Best Practices Applied

- Credentials are loaded from `.env`
- Migration examples are included in `src/db/migrations`
- Indexes are defined for frequent lookups in MongoDB and SQL models
- SQL models remain normalized while enrollment details are populated in MongoDB
