const { DataTypes } = require("sequelize");

const defineCourseModel = (sequelize) =>
  sequelize.define(
    "Course",
    {
      id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true
      },
      title: {
        type: DataTypes.STRING,
        allowNull: false
      },
      category: {
        type: DataTypes.STRING,
        allowNull: false
      },
      instructorId: {
        type: DataTypes.INTEGER,
        allowNull: false
      }
    },
    {
      tableName: "courses",
      indexes: [{ fields: ["instructorId"] }, { fields: ["title"] }]
    }
  );

module.exports = defineCourseModel;
