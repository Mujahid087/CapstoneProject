const defineInstructorModel = require("./Instructor");
const defineCourseModel = require("./Course");

const initSequelizeModels = (sequelize) => {
  const Instructor = defineInstructorModel(sequelize);
  const Course = defineCourseModel(sequelize);

  Instructor.hasMany(Course, {
    foreignKey: "instructorId",
    as: "courses"
  });

  Course.belongsTo(Instructor, {
    foreignKey: "instructorId",
    as: "instructor"
  });

  return {
    Instructor,
    Course
  };
};

module.exports = {
  initSequelizeModels
};
