const { DataTypes } = require("sequelize");

const defineInstructorModel = (sequelize) =>
  sequelize.define(
    "Instructor",
    {
      id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true
      },
      name: {
        type: DataTypes.STRING,
        allowNull: false
      },
      expertise: {
        type: DataTypes.STRING,
        allowNull: false
      }
    },
    {
      tableName: "instructors",
      indexes: [{ fields: ["name"] }]
    }
  );

module.exports = defineInstructorModel;
