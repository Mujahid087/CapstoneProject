const path = require("path");
const dotenv = require("dotenv");

dotenv.config({ path: path.resolve(process.cwd(), ".env") });

const getEnv = (key, fallback = undefined) => {
  const value = process.env[key];

  if (value === undefined || value === "") {
    return fallback;
  }

  return value;
};

module.exports = {
  mysql: {
    host: getEnv("MYSQL_HOST", "localhost"),
    port: Number(getEnv("MYSQL_PORT", 3306)),
    user: getEnv("MYSQL_USER", "root"),
    password: getEnv("MYSQL_PASSWORD", ""),
    database: getEnv("MYSQL_DATABASE", "skillsphere")
  },
  mongodb: {
    uri: getEnv("MONGODB_URI", "mongodb://127.0.0.1:27017/skillsphere")
  },
  sequelize: {
    dialect: getEnv("SEQUELIZE_DIALECT", "sqlite"),
    storage: getEnv("SEQUELIZE_STORAGE", "./data/skillsphere.sqlite"),
    database: getEnv("SEQUELIZE_DATABASE", "skillsphere"),
    username: getEnv("SEQUELIZE_USERNAME", "root"),
    password: getEnv("SEQUELIZE_PASSWORD", ""),
    host: getEnv("SEQUELIZE_HOST", "localhost"),
    port: Number(getEnv("SEQUELIZE_PORT", 3306))
  }
};
