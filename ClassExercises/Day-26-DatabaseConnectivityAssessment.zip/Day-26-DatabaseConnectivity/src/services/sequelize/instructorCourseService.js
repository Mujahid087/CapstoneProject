const seedInstructorCourses = async ({ Instructor, Course }) => {
  const existingInstructor = await Instructor.findOne({
    where: { name: "Nina Patel" }
  });

  if (existingInstructor) {
    return existingInstructor;
  }

  const instructor = await Instructor.create({
    name: "Nina Patel",
    expertise: "Database Systems"
  });

  await Course.bulkCreate([
    {
      title: "SQL Foundations",
      category: "Database",
      instructorId: instructor.id
    },
    {
      title: "NoSQL for Modern Apps",
      category: "Database",
      instructorId: instructor.id
    }
  ]);

  return instructor;
};

const getCoursesByInstructor = async ({ Instructor, Course }, instructorName) => {
  await seedInstructorCourses({ Instructor, Course });

  const instructor = await Instructor.findOne({
    where: { name: instructorName },
    include: [
      {
        model: Course,
        as: "courses"
      }
    ]
  });

  if (!instructor) {
    console.log(`No instructor found with name: ${instructorName}`);
    return null;
  }

  console.log(`Courses by ${instructor.name}:`);
  instructor.courses.forEach((course, index) => {
    console.log(`${index + 1}. ${course.title} (${course.category})`);
  });

  return instructor;
};

module.exports = {
  getCoursesByInstructor
};
