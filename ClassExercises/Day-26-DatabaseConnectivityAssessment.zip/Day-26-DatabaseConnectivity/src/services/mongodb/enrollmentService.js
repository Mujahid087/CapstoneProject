const Enrollment = require("../../models/mongodb/Enrollment");
const User = require("../../models/mongodb/User");

const seedMongoData = async () => {
  const existingUsers = await User.countDocuments();

  if (existingUsers > 0) {
    return;
  }

  const [admin, student] = await User.create([
    {
      name: "Ava Admin",
      email: "ava.admin@skillsphere.dev",
      role: "admin"
    },
    {
      name: "Ethan Student",
      email: "ethan.student@skillsphere.dev",
      role: "student"
    }
  ]);

  await Enrollment.create([
    {
      user: student._id,
      courseTitle: "Database Connectivity Essentials",
      status: "active"
    },
    {
      user: admin._id,
      courseTitle: "Platform Operations for Admins",
      status: "completed"
    }
  ]);
};

const fetchEnrollmentDetails = async () => {
  await seedMongoData();

  const enrollments = await Enrollment.find()
    .populate("user", "name email role")
    .sort({ enrolledAt: -1 })
    .lean();

  console.log("Enrollment details:");
  enrollments.forEach((enrollment, index) => {
    console.log(
      `${index + 1}. ${enrollment.user.name} (${enrollment.user.role}) -> ${enrollment.courseTitle} [${enrollment.status}]`
    );
  });

  return enrollments;
};

module.exports = {
  fetchEnrollmentDetails
};
