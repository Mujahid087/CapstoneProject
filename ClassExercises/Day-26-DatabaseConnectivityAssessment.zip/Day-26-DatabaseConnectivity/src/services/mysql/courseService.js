const { mysql: mysqlConfig } = require("../../config/env");

const createCoursesTableQuery = `
  CREATE TABLE IF NOT EXISTS courses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    category VARCHAR(100) NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_courses_category (category)
  )
`;

const ensureDatabaseQuery = `CREATE DATABASE IF NOT EXISTS \`${mysqlConfig.database}\``;

const sampleCourse = {
  title: "Database Design Masterclass",
  category: "Backend Development",
  price: 149.99
};

const ensureDatabaseExists = async (serverConnection) => {
  await serverConnection.execute(ensureDatabaseQuery);
};

const insertCourse = async (connection, course = sampleCourse) => {
  await connection.execute(createCoursesTableQuery);

  const insertQuery =
    "INSERT INTO courses (title, category, price) VALUES (?, ?, ?)";
  const [result] = await connection.execute(insertQuery, [
    course.title,
    course.category,
    course.price
  ]);

  console.log(
    `INSERT INTO courses successful. Course ID: ${result.insertId}, Title: ${course.title}`
  );

  return result;
};

module.exports = {
  ensureDatabaseExists,
  insertCourse,
  sampleCourse
};
