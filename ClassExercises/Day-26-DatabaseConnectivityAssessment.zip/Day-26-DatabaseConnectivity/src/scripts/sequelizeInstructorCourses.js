const { createSequelizeInstance } = require("../db/sequelize/connection");
const { initSequelizeModels } = require("../models/sequelize");
const {
  getCoursesByInstructor
} = require("../services/sequelize/instructorCourseService");

const run = async () => {
  const sequelize = createSequelizeInstance();
  const models = initSequelizeModels(sequelize);

  try {
    await sequelize.authenticate();
    await sequelize.sync();
    await getCoursesByInstructor(models, "Nina Patel");
  } finally {
    await sequelize.close();
  }
};

run().catch((error) => {
  console.error("Sequelize challenge failed:", error.message);
  process.exit(1);
});
