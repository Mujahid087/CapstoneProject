const {
  createMySqlConnection,
  createMySqlServerConnection
} = require("../db/mysql/connection");
const {
  ensureDatabaseExists,
  insertCourse
} = require("../services/mysql/courseService");

const run = async () => {
  const serverConnection = await createMySqlServerConnection();

  try {
    await ensureDatabaseExists(serverConnection);
  } finally {
    await serverConnection.end();
  }

  const connection = await createMySqlConnection();

  try {
    await insertCourse(connection);
  } finally {
    await connection.end();
  }
};

run().catch((error) => {
  console.error("MySQL challenge failed:", error.message);
  process.exit(1);
});
