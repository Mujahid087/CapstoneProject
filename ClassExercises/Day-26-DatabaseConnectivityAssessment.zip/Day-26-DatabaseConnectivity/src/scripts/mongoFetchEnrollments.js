const {
  connectMongoDb,
  disconnectMongoDb
} = require("../db/mongodb/connection");
const { fetchEnrollmentDetails } = require("../services/mongodb/enrollmentService");

const run = async () => {
  await connectMongoDb();

  try {
    await fetchEnrollmentDetails();
  } finally {
    await disconnectMongoDb();
  }
};

run().catch((error) => {
  console.error("MongoDB challenge failed:", error.message);
  process.exit(1);
});
