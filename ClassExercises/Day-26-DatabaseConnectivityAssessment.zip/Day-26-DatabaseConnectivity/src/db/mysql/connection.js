const mysql = require("mysql2/promise");
const { mysql: mysqlConfig } = require("../../config/env");

const baseConfig = {
  host: mysqlConfig.host,
  port: mysqlConfig.port,
  user: mysqlConfig.user,
  password: mysqlConfig.password
};

const createMySqlServerConnection = () =>
  mysql.createConnection({
    ...baseConfig
  });

const createMySqlConnection = () =>
  mysql.createConnection({
    ...baseConfig,
    database: mysqlConfig.database
  });

module.exports = {
  createMySqlServerConnection,
  createMySqlConnection
};
