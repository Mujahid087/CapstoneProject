const fs = require("fs");
const path = require("path");
const { Sequelize } = require("sequelize");
const { sequelize: sequelizeConfig } = require("../../config/env");

const createSequelizeInstance = () => {
  if (sequelizeConfig.dialect === "sqlite") {
    const storagePath = path.resolve(process.cwd(), sequelizeConfig.storage);
    fs.mkdirSync(path.dirname(storagePath), { recursive: true });

    return new Sequelize({
      dialect: "sqlite",
      storage: storagePath,
      logging: false
    });
  }

  return new Sequelize(
    sequelizeConfig.database,
    sequelizeConfig.username,
    sequelizeConfig.password,
    {
      host: sequelizeConfig.host,
      port: sequelizeConfig.port,
      dialect: sequelizeConfig.dialect,
      logging: false
    }
  );
};

module.exports = {
  createSequelizeInstance
};
