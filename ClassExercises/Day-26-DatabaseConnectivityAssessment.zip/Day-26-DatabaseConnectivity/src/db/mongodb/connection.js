const mongoose = require("mongoose");
const { mongodb } = require("../../config/env");

const connectMongoDb = async () => {
  await mongoose.connect(mongodb.uri);
};

const disconnectMongoDb = async () => {
  await mongoose.disconnect();
};

module.exports = {
  connectMongoDb,
  disconnectMongoDb
};
