const run = async () => {
  console.log("SkillSphere Day 26 assignment");
  console.log("Use one of the scripts:");
  console.log("  npm run mysql:insert");
  console.log("  npm run mongo:fetch");
  console.log("  npm run sequelize:demo");
};

run().catch((error) => {
  console.error("Application failed to start:", error.message);
  process.exit(1);
});
