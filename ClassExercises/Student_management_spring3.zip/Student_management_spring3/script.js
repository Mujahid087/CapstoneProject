

document.addEventListener('DOMContentLoaded', () => {

    showLogin();
});


function showLogin() {
    document.getElementById('authSection').style.display = 'block';
    document.getElementById('mainContent').style.display = 'none';
    
    document.getElementById('loginForm').classList.add('active');
    document.getElementById('registerForm').classList.remove('active');
}

function showRegister() {
    document.getElementById('authSection').style.display = 'block';
    document.getElementById('mainContent').style.display = 'none';

    document.getElementById('loginForm').classList.remove('active');
    document.getElementById('registerForm').classList.add('active');
}

function handleLogin(event) {
    event.preventDefault();

    const username = document.getElementById('loginUser').value;
    if (username) {
        alert('Login Successful!');
        showWelcome();
    } else {
        alert('Please enter a username');
    }
}

function handleRegister(event) {
    event.preventDefault();
    alert('Registration Successful! Please Login.');
    showLogin();
}

function logout() {
    showLogin();
}

function showWelcome() {
    document.getElementById('authSection').style.display = 'none';
    document.getElementById('mainContent').style.display = 'block';
    
    hideAllSections();
    document.getElementById("homeSection").style.display = "block";
}

function showProfile() {
    hideAllSections();
    document.getElementById("profileSection").style.display = "block";
}

function showTimeTable() {
    hideAllSections();
    document.getElementById("timeTableSection").style.display = "block";
}

function showMonthlyActivity() {
    hideAllSections();
    document.getElementById("activitySection").style.display = "block";
    renderActivities();
}

function hideAllSections() {
    const sections = ['homeSection', 'profileSection', 'timeTableSection', 'activitySection'];
    sections.forEach(id => {
        const el = document.getElementById(id);
        if (el) el.style.display = 'none';
    });
}


const activities = [
    { id: 1, activity: "Create project file which contains tables between 12 to 19", subject: "Maths" },
    { id: 2, activity: "Read Chapter 5: Forces and Motion", subject: "Science" },
    { id: 3, activity: "Complete grammar worksheet 3", subject: "English" },
    { id: 4, activity: "Solve 10 algebra problems", subject: "Maths" },
    { id: 5, activity: "Draw a map of India", subject: "Geography" }
];

function renderActivities() {
    const subjectFilter = document.getElementById('subjectFilter').value;
    const activityList = document.getElementById('activityList');
    activityList.innerHTML = '';

    const filteredActivities = subjectFilter === 'All' 
        ? activities 
        : activities.filter(a => a.subject === subjectFilter);

    if (filteredActivities.length === 0) {
        activityList.innerHTML = '<tr><td colspan="3" class="text-center">No activities found</td></tr>';
        return;
    }

    filteredActivities.forEach(activity => {
        const row = `
            <tr>
                <td>${activity.id}</td>
                <td>${activity.activity}</td>
                <td>${activity.subject}</td>
            </tr>
        `;
        activityList.innerHTML += row;
    });
}
