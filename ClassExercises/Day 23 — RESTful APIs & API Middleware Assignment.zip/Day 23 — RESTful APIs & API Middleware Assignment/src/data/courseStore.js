let nextId = 3;

const courses = [
  { id: 1, name: "JavaScript Basics", duration: "4 weeks" },
  { id: 2, name: "Node.js Fundamentals", duration: "6 weeks" }
];

const getAllCourses = () => courses;

const getCourseById = (id) => courses.find((course) => course.id === id);

const createCourse = ({ name, duration }) => {
  const newCourse = { id: nextId++, name, duration };
  courses.push(newCourse);
  return newCourse;
};

const updateCourse = (id, { name, duration }) => {
  const index = courses.findIndex((course) => course.id === id);
  if (index === -1) {
    return null;
  }

  courses[index] = { id, name, duration };
  return courses[index];
};

const deleteCourse = (id) => {
  const index = courses.findIndex((course) => course.id === id);
  if (index === -1) {
    return null;
  }

  const deleted = courses[index];
  courses.splice(index, 1);
  return deleted;
};

module.exports = {
  getAllCourses,
  getCourseById,
  createCourse,
  updateCourse,
  deleteCourse
};
