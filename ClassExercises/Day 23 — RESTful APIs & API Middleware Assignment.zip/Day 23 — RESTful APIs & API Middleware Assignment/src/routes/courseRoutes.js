const express = require("express");
const {
  listCourses,
  getCourse,
  addCourse,
  editCourse,
  removeCourse
} = require("../controllers/courseController");
const { validateCourse } = require("../validators/courseValidator");
const { validateRequest } = require("../middleware/validateRequest");

const router = express.Router();

router.get("/", listCourses);
router.get("/:id", getCourse);
router.post("/", validateCourse, validateRequest, addCourse);
router.put("/:id", validateCourse, validateRequest, editCourse);
router.delete("/:id", removeCourse);

module.exports = router;
