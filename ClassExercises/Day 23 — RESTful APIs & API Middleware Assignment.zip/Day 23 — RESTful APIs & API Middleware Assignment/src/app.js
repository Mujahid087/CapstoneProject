const express = require("express");
const courseRoutes = require("./routes/courseRoutes");
const { apiLimiter } = require("./config/rateLimiter");
const { notFound } = require("./middleware/notFound");
const { errorHandler } = require("./middleware/errorHandler");

const app = express();

app.use(express.json());
app.use("/api/v1", apiLimiter);
app.use("/api/v1/courses", courseRoutes);
app.use(notFound);
app.use(errorHandler);

module.exports = app;
