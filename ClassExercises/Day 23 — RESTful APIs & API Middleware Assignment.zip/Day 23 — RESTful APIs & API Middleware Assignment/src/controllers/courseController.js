const {
  getAllCourses,
  getCourseById,
  createCourse,
  updateCourse,
  deleteCourse
} = require("../data/courseStore");

const listCourses = (req, res) => {
  res.status(200).json(getAllCourses());
};

const getCourse = (req, res, next) => {
  const id = Number(req.params.id);
  const course = getCourseById(id);

  if (!course) {
    const error = new Error("Course not found");
    error.status = 404;
    return next(error);
  }

  res.status(200).json(course);
};

const addCourse = (req, res) => {
  const newCourse = createCourse({
    name: req.body.name.trim(),
    duration: req.body.duration.trim()
  });

  res.status(201).json(newCourse);
};

const editCourse = (req, res, next) => {
  const id = Number(req.params.id);
  const updatedCourse = updateCourse(id, {
    name: req.body.name.trim(),
    duration: req.body.duration.trim()
  });

  if (!updatedCourse) {
    const error = new Error("Course not found");
    error.status = 404;
    return next(error);
  }

  res.status(200).json(updatedCourse);
};

const removeCourse = (req, res, next) => {
  const id = Number(req.params.id);
  const deletedCourse = deleteCourse(id);

  if (!deletedCourse) {
    const error = new Error("Course not found");
    error.status = 404;
    return next(error);
  }

  res.status(200).json({
    message: "Course deleted successfully",
    course: deletedCourse
  });
};

module.exports = {
  listCourses,
  getCourse,
  addCourse,
  editCourse,
  removeCourse
};
