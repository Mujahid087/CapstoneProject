const { body } = require("express-validator");

const validateCourse = [
  body("name")
    .trim()
    .notEmpty()
    .withMessage("Course name is required"),
  body("duration")
    .trim()
    .notEmpty()
    .withMessage("Course duration is required")
];

module.exports = {
  validateCourse
};
