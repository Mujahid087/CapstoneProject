import React from 'react';

const StatsCard = React.memo(({ title, value, lastUpdated }) => {
    console.log(`Rendering StatsCard: ${title}`);

    return (
        <div className="card text-center mb-3">
            <div className="card-header bg-primary text-white">
                {title}
            </div>
            <div className="card-body">
                <h2 className="card-title">{value}</h2>
            </div>
            <div className="card-footer text-muted">
                Last updated: {lastUpdated}
            </div>
        </div>
    );
});

export default StatsCard;
