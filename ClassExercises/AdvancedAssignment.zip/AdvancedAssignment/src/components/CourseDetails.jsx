import React from 'react';

const CourseDetails = () => {
  return (
    <div className="card my-3">
      <div className="card-body">
        <h3 className="card-title">Course Details</h3>
        <p className="card-text">
          This course covers advanced React concepts including Lazy Loading, Error Boundaries,
          Pure Components, and Portals. By the end of this course, you will be able to build
          highly optimized and robust React applications.
        </p>
        <ul>
          <li>Module 1: Performance Optimization</li>
          <li>Module 2: Error Handling</li>
          <li>Module 3: Advanced UI Patterns</li>
        </ul>
      </div>
    </div>
  );
};

export default CourseDetails;
