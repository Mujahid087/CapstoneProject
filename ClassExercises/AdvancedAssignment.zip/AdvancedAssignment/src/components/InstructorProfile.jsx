import React from 'react';

const InstructorProfile = () => {
    return (
        <div className="card my-3">
            <div className="card-body text-center">
                <img
                    src="https://via.placeholder.com/150"
                    alt="Instructor"
                    className="rounded-circle mb-3"
                />
                <h4 className="card-title">Jane Doe</h4>
                <h6 className="card-subtitle mb-2 text-muted">Senior Software Engineer & Instructor</h6>
                <p className="card-text">
                    Jane has over 10 years of experience in full-stack web development and has
                    specialized in React, Node.js, and cloud architecture. She loves teaching
                    and helping developers build scalable applications.
                </p>
            </div>
        </div>
    );
};

export default InstructorProfile;
