import React, { useState } from 'react';

const BrokenProductCard = () => {
    const [hasError, setHasError] = useState(false);

    if (hasError) {
       
        throw new Error('Crashed while rendering ProductCard!');
    }

    return (
        <div className="card mb-3 border-danger">
            <div className="card-header text-danger">Fragile Component</div>
            <div className="card-body">
                <h5 className="card-title">Super Awesome Product</h5>
                <p className="card-text">
                    Clicking the button below will cause this component to throw a rendering error,
                    which will be caught by the Error Boundary.
                </p>
                <button
                    className="btn btn-outline-danger"
                    onClick={() => setHasError(true)}
                >
                    Break Component
                </button>
            </div>
        </div>
    );
};

export default BrokenProductCard;
