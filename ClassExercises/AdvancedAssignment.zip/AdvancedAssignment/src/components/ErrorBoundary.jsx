import React, { Component } from 'react';

class ErrorBoundary extends Component {
    constructor(props) {
        super(props);
        this.state = { hasError: false, error: null };
    }

    static getDerivedStateFromError(error) {
        
        return { hasError: true, error };
    }

    componentDidCatch(error, errorInfo) {
      
        console.error('ErrorBoundary caught an error:', error, errorInfo);
    }

    render() {
        if (this.state.hasError) {
          
            return (
                <div className="alert alert-danger p-4 m-3" role="alert">
                    <h4 className="alert-heading">Something went wrong!</h4>
                    <p>We apologize for the inconvenience. Our team has been notified.</p>
                    <hr />
                    <p className="mb-0 text-muted">
                        Error details: {this.state.error?.toString()}
                    </p>
                </div>
            );
        }

        return this.props.children;
    }
}

export default ErrorBoundary;
