import React, { useState, Suspense } from 'react';
import StatsCard from './components/StatsCard';
import ErrorBoundary from './components/ErrorBoundary';
import BrokenProductCard from './components/BrokenProductCard';
import Modal from './components/Modal';


const CourseDetails = React.lazy(() => import('./components/CourseDetails'));
const InstructorProfile = React.lazy(() => import('./components/InstructorProfile'));

function App() {

  const [showCourseDetails, setShowCourseDetails] = useState(false);
  const [showInstructorProfile, setShowInstructorProfile] = useState(false);

  const [stats, setStats] = useState([
    { id: 1, title: 'Total Students', value: 12500, lastUpdated: new Date().toLocaleTimeString() },
    { id: 2, title: 'Active Courses', value: 34, lastUpdated: new Date().toLocaleTimeString() },
    { id: 3, title: 'Server Uptime', value: '99.9%', lastUpdated: new Date().toLocaleTimeString() },
  ]);

  const [isModalOpen, setIsModalOpen] = useState(false);


  const handleSimulateUpdate = () => {

    setStats((prevStats) =>
      prevStats.map((stat, index) =>
        index === 0
          ? { ...stat, value: stat.value + 1, lastUpdated: new Date().toLocaleTimeString() }
          : stat
      )
    );
  };

  return (
    <div className="container py-4">
      <header className="pb-3 mb-4 border-bottom">
        <h1 className="display-5 fw-bold text-primary">React Advanced Concepts</h1>
        <p className="fs-5 text-muted">Day 14 Assignment Implementation</p>
      </header>


      <section className="mb-5">
        <h2 className="mb-3">Challenge 1: Lazy Loading & Code Splitting</h2>
        <div className="btn-group mb-3">
          <button
            className="btn btn-outline-primary"
            onClick={() => setShowCourseDetails(!showCourseDetails)}
          >
            {showCourseDetails ? 'Hide' : 'View'} Course Details
          </button>
          <button
            className="btn btn-outline-secondary"
            onClick={() => setShowInstructorProfile(!showInstructorProfile)}
          >
            {showInstructorProfile ? 'Hide' : 'View'} Instructor Profile
          </button>
        </div>

        <Suspense fallback={
          <div className="d-flex align-items-center text-primary mt-3">
            <div className="spinner-border ms-auto" role="status" aria-hidden="true"></div>
            <strong>Loading Module...</strong>
          </div>
        }>
          {showCourseDetails && <CourseDetails />}
          {showInstructorProfile && <InstructorProfile />}
        </Suspense>
      </section>


      <section className="mb-5 bg-light p-4 rounded">
        <div className="d-flex justify-content-between align-items-center mb-3">
          <h2>Challenge 2: Pure Components</h2>
          <button className="btn btn-success" onClick={handleSimulateUpdate}>
            Simulate Update (Only First Card)
          </button>
        </div>
        <p className="text-muted small">Open your console to see which components re-render.</p>
        <div className="row">
          {stats.map((stat) => (
            <div className="col-md-4" key={stat.id}>
              <StatsCard
                title={stat.title}
                value={stat.value}
                lastUpdated={stat.lastUpdated}
              />
            </div>
          ))}
        </div>
      </section>
      <section className="mb-5">
        <h2 className="mb-3">Challenge 3: Error Boundary</h2>
        <div className="row">
          <div className="col-md-6">
            <ErrorBoundary>
              <BrokenProductCard />
            </ErrorBoundary>
          </div>
          <div className="col-md-6">
            <div className="alert alert-info border-info h-100 d-flex flex-column justify-content-center">
              <h5>Safe Zone</h5>
              <p className="mb-0">
                This area is outside the broken component's tree so it remains untouched
                even when the other component crashes.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="mb-5 bg-dark text-white p-4 rounded text-center">
        <h2 className="mb-3">Challenge 4: Portals & Modals</h2>
        <p>
          Click the button below to open a modal that renders completely outside
          the main DOM hierarchy using React Portals.
        </p>
        <button className="btn btn-light btn-lg" onClick={() => setIsModalOpen(true)}>
          Open Notification Modal
        </button>

        <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="Important Notification">
          <div className="text-center p-3">
            <h4 className="text-success mb-3">Action Successful!</h4>
            <p>
              This is a portal modal. It breaks out of the CSS containments
              and parent hierarchy to display freely over your content.
            </p>
          </div>
        </Modal>
      </section>

    </div>
  );
}

export default App;
