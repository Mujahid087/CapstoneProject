import React, { useState } from 'react';
import BookCard from './BookCard';

// Book data array
const booksData = [
  {
    id: 1,
    title: 'The Great Gatsby',
    author: 'F. Scott Fitzgerald',
    price: 10.99,
    image: 'https://covers.openlibrary.org/b/id/7222246-L.jpg',
  },
  {
    id: 2,
    title: 'To Kill a Mockingbird',
    author: 'Harper Lee',
    price: 12.49,
    image: 'https://covers.openlibrary.org/b/id/8228691-L.jpg',
  },
  {
    id: 3,
    title: '1984',
    author: 'George Orwell',
    price: 9.99,
    image: 'https://covers.openlibrary.org/b/id/7222246-L.jpg',
  },
  {
    id: 4,
    title: 'Pride and Prejudice',
    author: 'Jane Austen',
    price: 8.99,
    image: 'https://covers.openlibrary.org/b/id/12645114-L.jpg',
  },
  {
    id: 5,
    title: 'The Catcher in the Rye',
    author: 'J.D. Salinger',
    price: 11.49,
    image: 'https://covers.openlibrary.org/b/id/8231856-L.jpg',
  },
  {
    id: 6,
    title: 'Moby Dick',
    author: 'Herman Melville',
    price: 13.99,
    image: 'https://covers.openlibrary.org/b/id/7222246-L.jpg',
  },
];

function BookList() {
  // State for view mode (grid or list)
  const [viewMode, setViewMode] = useState('grid');

  // State for search query
  const [searchQuery, setSearchQuery] = useState('');

  // Filter books based on search query
  const filteredBooks = booksData.filter(
    (book) =>
      book.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      book.author.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <section className="book-list-section" id="featured">
      <h2 className="section-title">Featured Books</h2>

      {/* Controls - Search and View Toggle */}
      <div className="controls">
        <input
          type="text"
          placeholder="Search by title or author..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="search-input"
        />

        <div className="view-toggle">
          <button
            className={`toggle-btn ${viewMode === 'grid' ? 'active' : ''}`}
            onClick={() => setViewMode('grid')}
          >
            Grid
          </button>
          <button
            className={`toggle-btn ${viewMode === 'list' ? 'active' : ''}`}
            onClick={() => setViewMode('list')}
          >
            List
          </button>
        </div>
      </div>

      {/* Books Display */}
      <div className={`books-container ${viewMode}`}>
        {filteredBooks.length > 0 ? (
          filteredBooks.map((book) => (
            <BookCard
              key={book.id}
              title={book.title}
              author={book.author}
              price={book.price}
              image={book.image}
              viewMode={viewMode}
            />
          ))
        ) : (
          <div className="no-results">
            <p>No books found for "{searchQuery}"</p>
          </div>
        )}
      </div>
    </section>
  );
}

export default BookList;
