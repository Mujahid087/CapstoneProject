import React from 'react';

function BookCard({ title, author, price, image, viewMode }) {
  return (
    <div className={`book-card ${viewMode}`}>
      <div className="book-card-image">
        <img src={image} alt={title} />
      </div>
      <div className="book-card-info">
        <h3 className="book-title">{title}</h3>
        <p className="book-author">by {author}</p>
        <span className="book-price">${price.toFixed(2)}</span>
      </div>
    </div>
  );
}

export default BookCard;
