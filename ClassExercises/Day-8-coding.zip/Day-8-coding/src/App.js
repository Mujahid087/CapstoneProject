import React from 'react';
import './App.css';
import BookList from './components/BookList';

function App() {
  return (
    <div className="App">
      {/* Navbar */}
      <nav className="navbar">
        <span className="brand-name">📚 BookVerse</span>
        <ul className="nav-links">
          <li><a href="#home">Home</a></li>
          <li><a href="#featured">Featured</a></li>
        </ul>
      </nav>

      {/* Hero Section */}
      <header className="hero" id="home">
        <h1 className="hero-title">
          Welcome to <span className="highlight">BookVerse</span>
        </h1>
        <p className="hero-subtitle">
          Discover popular books from our featured collection.
        </p>
        <a href="#featured" className="hero-btn">
          Explore Books
        </a>
      </header>

      {/* Featured Books */}
      <main>
        <BookList />
      </main>

      {/* Footer */}
      <footer className="footer">
        <p>&copy; 2026 BookVerse. Built with React.</p>
      </footer>
    </div>
  );
}

export default App;
