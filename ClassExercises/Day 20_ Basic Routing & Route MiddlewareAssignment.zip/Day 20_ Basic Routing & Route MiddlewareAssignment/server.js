const express = require("express");
const coursesRoute = require("./routes/courses");

const app = express();
const PORT = 4000;

app.get("/", (req, res) => {
  res.send("Welcome to SkillSphere LMS API");
});

app.use("/courses", coursesRoute);

app.listen(PORT, () => {
  console.log(`SkillSphere LMS API is running on http://localhost:${PORT}`);
});
