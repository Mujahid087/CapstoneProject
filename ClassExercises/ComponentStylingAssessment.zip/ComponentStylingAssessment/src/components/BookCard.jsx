import React from 'react';
import PropTypes from 'prop-types';

const BookCard = ({ title, author, description, coverImage, onSelectAuthor }) => {
  return (
    <div className="card h-100 shadow-sm">
      {coverImage && (
        <img 
          src={coverImage} 
          className="card-img-top book-cover" 
          alt={`${title} cover`} 
        />
      )}
      <div className="card-body d-flex flex-column">
        <h5 className="card-title text-primary fw-bold" style={{ cursor: 'pointer' }} onClick={() => onSelectAuthor(author)}>
          {title}
        </h5>
        <h6 className="card-subtitle mb-2 text-muted" style={{ cursor: 'pointer' }} onClick={() => onSelectAuthor(author)}>
          By {author}
        </h6>
        <p className="card-text flex-grow-1">{description}</p>
        <button 
          className="btn btn-outline-primary mt-auto"
          onClick={() => onSelectAuthor(author)}
        >
          View Author Details
        </button>
      </div>
    </div>
  );
};

BookCard.propTypes = {
  title: PropTypes.string.isRequired,
  author: PropTypes.string.isRequired,
  description: PropTypes.string,
  coverImage: PropTypes.string,
  onSelectAuthor: PropTypes.func.isRequired,
};

export default BookCard;
