import React, { Component } from 'react';
import PropTypes from 'prop-types';

class AuthorInfo extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isLoading: true,
            authorDetails: null
        };
    }

    componentDidMount() {
        this.fetchAuthorData(this.props.authorName);
    }

    componentDidUpdate(prevProps) {
        if (prevProps.authorName !== this.props.authorName) {
            this.fetchAuthorData(this.props.authorName);
        }
    }

    fetchAuthorData(authorName) {
        console.log(`Loading data for author: ${authorName}`);
        this.setState({ isLoading: true });

       
        setTimeout(() => {
            const mockAuthorsDb = {
                'J.R.R. Tolkien': {
                    bio: 'John Ronald Reuel Tolkien was an English writer, poet, philologist, and academic, best known as the author of the high fantasy works The Hobbit and The Lord of the Rings.',
                    books: ['The Hobbit', 'The Fellowship of the Ring', 'The Two Towers']
                },
                'George R.R. Martin': {
                    bio: 'George Raymond Richard Martin, also known as GRRM, is an American novelist and short story writer in the fantasy, horror, and science fiction genres, screenwriter, and television producer.',
                    books: ['A Game of Thrones', 'A Clash of Kings', 'A Storm of Swords']
                },
                'J.K. Rowling': {
                    bio: 'Joanne Rowling, better known by her pen name J. K. Rowling, is a British author, philanthropist, film producer, television producer, and screenwriter.',
                    books: ['Harry Potter and the Philosopher\'s Stone', 'Harry Potter and the Chamber of Secrets', 'Harry Potter and the Prisoner of Azkaban']
                },
                'Agatha Christie': {
                    bio: 'Dame Agatha Mary Clarissa Christie, Lady Mallowan, DBE was an English writer known for her 66 detective novels and 14 short story collections.',
                    books: ['And Then There Were None', 'Murder on the Orient Express', 'The Murder of Roger Ackroyd']
                }
            };

            const defaultBio = 'An intriguing author with many captivating works. Stay tuned for more detailed biographical information.';
            const defaultBooks = ['Featured Book One', 'Bestseller Two', 'Recent Work Three'];

            this.setState({
                isLoading: false,
                authorDetails: mockAuthorsDb[authorName] || { bio: defaultBio, books: defaultBooks }
            });

            console.log(`Data loading complete for ${authorName}.`);
        }, 1000);
    }

    render() {
        const { authorName } = this.props;
        const { isLoading, authorDetails } = this.state;

        return (
            <div className="card mt-4 shadow-sm border-secondary animated slideInUp">
                <div className="card-header bg-dark text-white">
                    <h4 className="mb-0">
                        <i className="bi bi-person-lines-fill me-2"></i>
                        Author Spotlight: {authorName}
                    </h4>
                </div>
                <div className="card-body bg-light">
                    {isLoading ? (
                        <div className="d-flex justify-content-center align-items-center py-4">
                            <div className="spinner-border text-primary" role="status">
                                <span className="visually-hidden">Loading...</span>
                            </div>
                            <span className="ms-3 text-secondary">Fetching author profile...</span>
                        </div>
                    ) : (
                        <div className="row">
                            <div className="col-md-7">
                                <h5 className="text-secondary border-bottom pb-2">Biography</h5>
                                <p className="lead" style={{ fontSize: '1.1rem' }}>{authorDetails.bio}</p>
                            </div>
                            <div className="col-md-5 mt-4 mt-md-0">
                                <h5 className="text-secondary border-bottom pb-2">Popular Books</h5>
                                <ul className="list-group list-group-flush shadow-sm rounded">
                                    {authorDetails.books.map((book, index) => (
                                        <li key={index} className="list-group-item list-group-item-action d-flex align-items-center">
                                            <span className="badge bg-primary rounded-pill me-3">{index + 1}</span>
                                            {book}
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        );
    }
}

AuthorInfo.propTypes = {
    authorName: PropTypes.string.isRequired
};

export default AuthorInfo;
