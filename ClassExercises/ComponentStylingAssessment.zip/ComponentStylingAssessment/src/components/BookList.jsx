import React, { useState } from 'react';
import PropTypes from 'prop-types';
import BookCard from './BookCard';
import AuthorInfo from './AuthorInfo';

const mockBooks = [
    { id: 1, title: 'The Hobbit', author: 'J.R.R. Tolkien', description: 'A hobbit goes on an unexpected journey.', coverImage: 'https://placehold.co/150x200/2a9d8f/white?text=The+Hobbit' },
    { id: 2, title: 'A Game of Thrones', author: 'George R.R. Martin', description: 'Noble families vie for control of the Iron Throne.', coverImage: 'https://placehold.co/150x200/e76f51/white?text=Game+of+Thrones' },
    { id: 3, title: 'Harry Potter and the Philosopher\'s Stone', author: 'J.K. Rowling', description: 'A young boy discovers he is a wizard.', coverImage: 'https://placehold.co/150x200/e9c46a/white?text=Harry+Potter' },
    { id: 4, title: 'And Then There Were None', author: 'Agatha Christie', description: 'Ten strangers are invited to an isolated island.', coverImage: 'https://placehold.co/150x200/264653/white?text=And+Then+There...' }
];

const BookList = ({ searchTerm }) => {
    const [selectedAuthor, setSelectedAuthor] = useState(null);

    const handleSelectAuthor = (authorName) => {
        setSelectedAuthor(authorName);

        window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    const filteredBooks = mockBooks.filter(book =>
        book.title.toLowerCase().includes((searchTerm || '').toLowerCase()) ||
        book.author.toLowerCase().includes((searchTerm || '').toLowerCase())
    );

    return (
        <div className="mt-4">
            
            {selectedAuthor && (
                <div className="row mb-5 justify-content-center">
                    <div className="col-lg-10 col-xl-8">
                        <AuthorInfo authorName={selectedAuthor} />
                        <div className="text-end mt-2">
                            <button
                                className="btn btn-sm btn-outline-danger"
                                onClick={() => setSelectedAuthor(null)}
                            >
                                Close Author Info
                            </button>
                        </div>
                    </div>
                </div>
            )}

           
            <h3 className="mb-4 text-secondary border-bottom pb-2">Featured Books</h3>
            <div className="row row-cols-1 row-cols-md-2 row-cols-lg-4 g-4">
                {filteredBooks.length > 0 ? (
                    filteredBooks.map((book) => (
                        <div className="col" key={book.id}>
                            <BookCard
                                title={book.title}
                                author={book.author}
                                description={book.description}
                                coverImage={book.coverImage}
                                onSelectAuthor={handleSelectAuthor}
                            />
                        </div>
                    ))
                ) : (
                    <div className="col-12 py-5 text-center text-muted">
                        <i className="bi bi-search fs-1 mb-3 d-block"></i>
                        <h5>No books found matching "{searchTerm}".</h5>
                        <p>Try a different search term or clear the search.</p>
                    </div>
                )}
            </div>
        </div>
    );
};

BookList.propTypes = {
    searchTerm: PropTypes.string
};

BookList.defaultProps = {
    searchTerm: ''
};

export default BookList;
