import React, { useState, useRef } from 'react';
import BookList from './components/BookList';
import './index.css';

function App() {
  const [searchTerm, setSearchTerm] = useState('');
 
  const searchInputRef = useRef(null);

  const handleFocusSearch = () => {
    if (searchInputRef.current) {
      searchInputRef.current.focus();
    }
  };

  const handleSearchChange = (e) => {
    setSearchTerm(e.target.value);
  };

  return (
    <div className="app-container bg-light min-vh-100 pb-5">

      <header className="hero-header text-white text-center py-5 mb-5 shadow">
        <div className="container py-4">
          <h1 className="display-3 fw-bold mb-3 title-shadow">
            BookVerse
          </h1>
          <p className="lead fs-4 opacity-75">Discover your next great read and explore author biographies.</p>
        </div>
      </header>

      <div className="container">
    
        <section className="search-section card shadow-sm mb-5 border-0 bg-white rounded-3">
          <div className="card-body p-4">
            <h5 className="mb-3 text-secondary">Find a Book</h5>
            <div className="row align-items-center g-3">
              <div className="col-lg-8">
                <input
                  type="text"
                  className="form-control form-control-lg search-input"
                  placeholder="Search by book title or author..."
                  aria-label="Search"
                  value={searchTerm}
                  onChange={handleSearchChange}
                  ref={searchInputRef}
                />
              </div>
              <div className="col-lg-4">
                <button
                  className="btn btn-primary btn-lg w-100 focus-btn"
                  onClick={handleFocusSearch}
                >
                  Focus Search Input
                </button>
              </div>
            </div>
          </div>
        </section>

        <main>
          <BookList searchTerm={searchTerm} />
        </main>

        <footer className="text-center mt-5 pt-4 border-top text-muted">
          <p>&copy; {new Date().getFullYear()} BookVerse. Designed for readers everywhere.</p>
        </footer>
      </div>
    </div>
  );
}

export default App;
