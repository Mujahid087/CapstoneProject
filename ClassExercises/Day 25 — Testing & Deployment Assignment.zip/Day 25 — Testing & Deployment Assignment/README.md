# SkillSphere API - Day 25 (Testing & Deployment)

## Features
- `GET /status` returns `App is live`
- `GET /api/courses`
- `GET /api/courses/:id`
- `GET /api/users`
- `POST /api/users` (validated by middleware)

## Setup
```bash
npm install
```

## Run Locally
```bash
npm start
```
Server uses:
- `process.env.PORT` (falls back to `3000`)

## Testing
```bash
npm test
npm run ci:test
```
- Test stack: Mocha + Chai + SuperTest
- Coverage: NYC with strict 100% gates (lines/functions/branches/statements)

## Deployment Files Included
- `render.yaml` (Render blueprint)
- `.github/workflows/ci.yml` (CI test automation)

## Live Deployment
- Base URL: `https://day-25-assignment.onrender.com`
- Status URL: `https://day-25-assignment.onrender.com/status`

## Render Deployment
1. Push this project to GitHub.
2. In Render, create a **Web Service** from the repo.
3. Set:
   - Build Command: `npm install`
   - Start Command: `npm start`
4. Add env var:
   - `NODE_ENV=production`
   - `PORT` is auto-provided by Render (do not hardcode).
5. After deploy, verify:
   - `https://day-25-assignment.onrender.com/status` -> `App is live`
