const { expect } = require("chai");
const {
  listCourses,
  getCourseById
} = require("../../src/controllers/coursesController");

function createMockRes() {
  return {
    statusCode: null,
    body: null,
    status(code) {
      this.statusCode = code;
      return this;
    },
    json(payload) {
      this.body = payload;
      return this;
    }
  };
}

describe("Unit Tests: /api/courses controller", () => {
  it("should return all courses", () => {
    const req = {};
    const res = createMockRes();

    listCourses(req, res);

    expect(res.statusCode).to.equal(200);
    expect(res.body.success).to.equal(true);
    expect(res.body.data).to.be.an("array").with.length(2);
  });

  it("should return a course by id when found", () => {
    const req = { params: { id: "1" } };
    const res = createMockRes();

    getCourseById(req, res);

    expect(res.statusCode).to.equal(200);
    expect(res.body.success).to.equal(true);
    expect(res.body.data).to.deep.equal({
      id: 1,
      title: "Node.js Basics",
      level: "Beginner"
    });
  });

  it("should return 404 when course id does not exist", () => {
    const req = { params: { id: "999" } };
    const res = createMockRes();

    getCourseById(req, res);

    expect(res.statusCode).to.equal(404);
    expect(res.body.success).to.equal(false);
    expect(res.body.message).to.equal("Course not found");
  });
});
