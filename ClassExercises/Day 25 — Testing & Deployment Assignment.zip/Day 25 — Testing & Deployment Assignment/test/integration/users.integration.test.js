const request = require("supertest");
const { expect } = require("chai");
const app = require("../../src/app");

describe("Integration Tests: /api/users", () => {
  it("should return users list", async () => {
    const response = await request(app).get("/api/users");

    expect(response.status).to.equal(200);
    expect(response.body.success).to.equal(true);
    expect(response.body.data).to.be.an("array").with.length(2);
  });

  it("should create user when middleware validation passes", async () => {
    const payload = {
      name: "Charlie",
      role: "student"
    };

    const response = await request(app).post("/api/users").send(payload);

    expect(response.status).to.equal(201);
    expect(response.body.success).to.equal(true);
    expect(response.body.message).to.equal("User created");
    expect(response.body.data.name).to.equal("Charlie");
    expect(response.body.data.role).to.equal("student");
  });

  it("should reject user creation when name is missing", async () => {
    const response = await request(app).post("/api/users").send({
      role: "student"
    });

    expect(response.status).to.equal(400);
    expect(response.body.success).to.equal(false);
    expect(response.body.message).to.equal("Valid name is required");
  });

  it("should reject user creation when role is invalid", async () => {
    const response = await request(app).post("/api/users").send({
      name: "Daisy",
      role: "admin"
    });

    expect(response.status).to.equal(400);
    expect(response.body.success).to.equal(false);
    expect(response.body.message).to.equal(
      "Role must be either student or instructor"
    );
  });
});
