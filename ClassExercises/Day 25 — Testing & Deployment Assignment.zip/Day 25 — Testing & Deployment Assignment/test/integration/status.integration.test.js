const request = require("supertest");
const { expect } = require("chai");
const app = require("../../src/app");

describe("Integration Tests: /status", () => {
  it('should return "App is live"', async () => {
    const response = await request(app).get("/status");

    expect(response.status).to.equal(200);
    expect(response.text).to.equal("App is live");
  });

  it("should return 404 for unknown route", async () => {
    const response = await request(app).get("/not-found");

    expect(response.status).to.equal(404);
    expect(response.body.success).to.equal(false);
    expect(response.body.message).to.equal("Route not found");
  });
});
