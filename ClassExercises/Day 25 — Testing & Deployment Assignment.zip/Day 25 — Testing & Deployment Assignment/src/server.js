require("dotenv").config();
const app = require("./app");

const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
  // Keep boot logs minimal and explicit in production.
  console.log(`SkillSphere API listening on port ${PORT}`);
});
