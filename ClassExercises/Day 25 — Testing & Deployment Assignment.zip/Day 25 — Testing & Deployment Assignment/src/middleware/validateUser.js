function validateUser(req, res, next) {
  const { name, role } = req.body;

  if (!name || typeof name !== "string" || !name.trim()) {
    return res.status(400).json({
      success: false,
      message: "Valid name is required"
    });
  }

  if (!role || !["student", "instructor"].includes(role)) {
    return res.status(400).json({
      success: false,
      message: "Role must be either student or instructor"
    });
  }

  return next();
}

module.exports = validateUser;
