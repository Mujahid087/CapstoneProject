const express = require("express");
const {
  listCourses,
  getCourseById
} = require("../controllers/coursesController");

const router = express.Router();

router.get("/", listCourses);
router.get("/:id", getCourseById);

module.exports = router;
