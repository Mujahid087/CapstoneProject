const express = require("express");
const { listUsers, createUser } = require("../controllers/usersController");
const validateUser = require("../middleware/validateUser");

const router = express.Router();

router.get("/", listUsers);
router.post("/", validateUser, createUser);

module.exports = router;
