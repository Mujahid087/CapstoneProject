const express = require("express");
const compression = require("compression");
const coursesRoutes = require("./routes/courses");
const usersRoutes = require("./routes/users");

const app = express();

app.use(compression());
app.use(express.json());

app.get("/status", (req, res) => {
  return res.status(200).send("App is live");
});

app.use("/api/courses", coursesRoutes);
app.use("/api/users", usersRoutes);

app.use((req, res) => {
  return res.status(404).json({
    success: false,
    message: "Route not found"
  });
});

module.exports = app;
