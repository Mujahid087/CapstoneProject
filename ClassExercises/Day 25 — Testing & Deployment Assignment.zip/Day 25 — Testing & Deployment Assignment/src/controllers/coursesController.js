function listCourses(req, res) {
  return res.status(200).json({
    success: true,
    data: [
      { id: 1, title: "Node.js Basics", level: "Beginner" },
      { id: 2, title: "Advanced Express", level: "Intermediate" }
    ]
  });
}

function getCourseById(req, res) {
  const courseId = Number(req.params.id);
  const courses = [
    { id: 1, title: "Node.js Basics", level: "Beginner" },
    { id: 2, title: "Advanced Express", level: "Intermediate" }
  ];

  const course = courses.find((item) => item.id === courseId);
  if (!course) {
    return res.status(404).json({
      success: false,
      message: "Course not found"
    });
  }

  return res.status(200).json({
    success: true,
    data: course
  });
}

module.exports = {
  listCourses,
  getCourseById
};
