function listUsers(req, res) {
  return res.status(200).json({
    success: true,
    data: [
      { id: 1, name: "Alice", role: "student" },
      { id: 2, name: "Bob", role: "instructor" }
    ]
  });
}

function createUser(req, res) {
  const { name, role } = req.body;
  return res.status(201).json({
    success: true,
    message: "User created",
    data: {
      id: 3,
      name,
      role
    }
  });
}

module.exports = {
  listUsers,
  createUser
};
