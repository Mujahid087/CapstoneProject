const express = require("express");
const cors = require("cors");
const bookRouter = require("./routes/books");

const app = express();
const PORT = 4000;

app.use(cors());
app.use(express.json());

app.use((req, res, next) => {
  const timestamp = new Date().toISOString();
  console.log(`[${req.method}] ${req.url} - ${timestamp}`);
  next();
});

app.get("/", (req, res) => {
  res.send("Welcome to Express Server");
});

app.get("/status", (req, res) => {
  res.json({ server: "running", uptime: "OK" });
});

app.get("/products", (req, res) => {
  const { name } = req.query;
  if (name) {
    return res.json({ query: name, message: `Searching for product: ${name}` });
  }
  res.json({ message: "Please provide a product name" });
});

app.use("/books", bookRouter);

app.use((req, res) => {
  res.status(404).json({ error: "Route not found" });
});

app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: "Internal Server Error" });
});

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
