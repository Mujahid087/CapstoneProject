const moment = require("moment");


const name = process.argv[2];


if (!name) {
  console.log("Please provide your name as an argument.");
  console.log("Usage: node greet.js <YourName>");
  process.exit(1);
}


const dateTime = moment().format("ddd MMM D YYYY, h:mm A");


console.log(`Hello, ${name}! Today is ${dateTime}`);
