const chalk = require("chalk");
const figlet = require("figlet");


figlet("Welcome to Node.js", (err, data) => {
  if (err) {
    console.log("Something went wrong with figlet.");
    console.log(err);
    return;
  }
  console.log(chalk.green.bold(data));
  console.log(chalk.cyan("This message is powered by npm packages: chalk & figlet"));
});
