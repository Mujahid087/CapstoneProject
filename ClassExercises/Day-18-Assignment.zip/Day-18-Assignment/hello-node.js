
console.log("Node.js Version:", process.version);

console.log("Current File Name:", __filename);
console.log("Current Directory:", __dirname);


let count = 0;

const intervalId = setInterval(() => {
  count++;
  console.log(`Welcome to Node.js! (Message #${count})`);
}, 3000);


setTimeout(() => {
  clearInterval(intervalId);
  console.log("Timer stopped after 10 seconds. Goodbye!");
}, 10000);
