create database TechNovaDB; 

use TechNovaDB;


-- creating the tables 

CREATE TABLE DEPARTMENT (
DeptID INT PRIMARY KEY, 
DeptName VARCHAR(50) NOT NULL UNIQUE, 
Location varchar(50)
);

create table Employee (
EmpID int primary key,
EmpName varchar(100) not null, 
Gender char(1),
DOB date,
HireDate date,
DeptID INT,
Foreign key(DeptID) references DEPARTMENT(DeptID)
); 


create table Project (
ProjectID int primary key, 
ProjectName varchar(100),
DeptID int, 
StartDate date,
EndDate date, 
foreign key (DeptID) references DEPARTMENT(DeptID)

);

CREATE TABLE Performance(
EmpID int,
ProjectID INT, 
Rating DECIMAL(3,1),
ReviewDate DATE,
primary key (EmpID,ProjectID),
foreign key(EmpID) REFERENCES Employee(EmpID),
foreign key(ProjectID) REFERENCES Project(ProjectID)
);
CREATE TABLE Reward (
    EmpID INT,
    RewardMonth DATE,
    RewardAmount DECIMAL(10,2),
    PRIMARY KEY (EmpID, RewardMonth),
    FOREIGN KEY (EmpID) REFERENCES Employee(EmpID)
);


-- creating the indexes 

CREATE INDEX idx_empname ON Employee(EmpName);

CREATE INDEX idx_deptid ON Employee(DeptID);

-- inserting the values in the tables 

INSERT INTO DEPARTMENT VALUES
(101,'IT','Bangalore'),
(102,'HR','Delhi'),
(103,'Finance','Mumbai'),
(104,'Marketing','Chennai'),
(105,'Sales','Hyderabad');


INSERT INTO Employee VALUES
(1,'Asha','F','1990-07-12','2018-06-10',101),
(2,'Raj','M','1988-04-09','2020-03-22',102),
(3,'Neha','F','1995-01-15','2021-08-05',101),
(4,'Arjun','M','1992-11-20','2019-07-12',103),
(5,'Priya','F','1996-05-18','2022-01-15',104);


INSERT INTO Project VALUES
(201,'Website Revamp',101,'2023-01-01','2023-06-30'),
(202,'HR Automation',102,'2023-02-10','2023-07-15'),
(203,'Finance Analytics',103,'2023-03-05','2023-08-20'),
(204,'Marketing Campaign',104,'2023-04-01','2023-09-30'),
(205,'Sales Dashboard',105,'2023-05-01','2023-10-30');

INSERT INTO Performance VALUES
(1,201,4.5,'2023-06-30'),
(2,202,4.0,'2023-07-15'),
(3,201,4.7,'2023-06-30'),
(4,203,3.9,'2023-08-20'),
(5,204,4.2,'2023-09-30');


INSERT INTO Reward VALUES
(1,'2024-01-01',2500),
(2,'2024-02-01',1500),
(3,'2024-03-01',3000),
(4,'2024-01-01',900),
(5,'2024-02-01',1800); 

-- updating the employee department 

UPDATE Employee
SET DeptID = 105
WHERE EmpID = 3;

SET SQL_SAFE_UPDATES = 0;

-- delete reward less than 1000 

DELETE FROM Reward
WHERE RewardAmount < 1000;

-- 3. DQL 
-- Employees who joined after 2019 
SELECT *
FROM Employee
WHERE HireDate > '2019-01-01';

-- Average Rating by Department 
SELECT d.DeptName,
       AVG(p.Rating) AS AvgRating
FROM Performance p
JOIN Employee e ON p.EmpID = e.EmpID
JOIN Department d ON e.DeptID = d.DeptID
GROUP BY d.DeptName;


-- Employees with Age 
SELECT EmpName,
       TIMESTAMPDIFF(YEAR, DOB, CURDATE()) AS Age
FROM Employee;


-- Total Rewards in Current Year 
SELECT SUM(RewardAmount) AS TotalRewards
FROM Reward
WHERE YEAR(RewardMonth) = YEAR(CURDATE());

-- Employees with Rewards Greater than 2000 

SELECT e.EmpName, r.RewardAmount
FROM Employee e
JOIN Reward r ON e.EmpID = r.EmpID
WHERE r.RewardAmount > 2000;

-- 4. Advanced Queries 

-- Employee + Department + Project + Rating 
SELECT e.EmpName,
       d.DeptName,
       pr.ProjectName,
       pf.Rating
FROM Employee e
JOIN Department d ON e.DeptID = d.DeptID
JOIN Performance pf ON e.EmpID = pf.EmpID
JOIN Project pr ON pf.ProjectID = pr.ProjectID;


-- Highest Rated Employee in Each Department 
SELECT e.EmpName, d.DeptName, p.Rating
FROM Performance p
JOIN Employee e ON p.EmpID = e.EmpID
JOIN Department d ON e.DeptID = d.DeptID
WHERE p.Rating = (
    SELECT MAX(p2.Rating)
    FROM Performance p2
    JOIN Employee e2 ON p2.EmpID = e2.EmpID
    WHERE e2.DeptID = e.DeptID
);

 -- Employees Who Did Not Receive Rewards 
SELECT EmpName
FROM Employee
WHERE EmpID NOT IN (
    SELECT EmpID FROM Reward
);

-- 5.Transaction Control 

START TRANSACTION;

INSERT INTO Employee VALUES
(6,'Rahul','M','1994-03-10','2024-01-15',101);

INSERT INTO Performance VALUES
(6,201,4.3,'2024-06-01');

COMMIT;

-- Query Optimization using EXPLAIN 


-- Before Index 
EXPLAIN
SELECT e.EmpName, d.DeptName, p.ProjectName
FROM Employee e
JOIN Department d ON e.DeptID = d.DeptID
JOIN Project p ON d.DeptID = p.DeptID;

-- After Index 

CREATE INDEX idx_project_deptid ON Project(DeptID);

EXPLAIN
SELECT e.EmpName, d.DeptName, p.ProjectName
FROM Employee e
JOIN Department d ON e.DeptID = d.DeptID
JOIN Project p ON d.DeptID = p.DeptID;



-- Bonus Challenge
-- Create View 

CREATE VIEW EmployeePerformanceView AS
SELECT e.EmpName,
       d.DeptName,
       p.ProjectName,
       pf.Rating
FROM Employee e
JOIN Department d ON e.DeptID = d.DeptID
JOIN Performance pf ON e.EmpID = pf.EmpID
JOIN Project p ON pf.ProjectID = p.ProjectID;

DELIMITER $$

CREATE PROCEDURE GetTopPerformers(IN deptName VARCHAR(50))
BEGIN
    SELECT e.EmpName, p.Rating
    FROM Employee e
    JOIN Department d ON e.DeptID = d.DeptID
    JOIN Performance p ON e.EmpID = p.EmpID
    WHERE d.DeptName = deptName
    ORDER BY p.Rating DESC
    LIMIT 3;
END $$

DELIMITER ;


CALL GetTopPerformers('IT');
