import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import withLoading from '../components/withLoading';
import { ArrowLeft, Star, Calendar, User } from 'lucide-react';

const BookDetailsContent = ({ book }) => {
    const navigate = useNavigate();

    if (!book) return null;

    return (
        <div>
            <button
                onClick={() => navigate('/home')}
                style={{
                    background: 'transparent', border: 'none', color: 'var(--text-secondary)',
                    display: 'flex', alignItems: 'center', gap: '0.5rem', cursor: 'pointer',
                    marginBottom: '2rem', fontSize: '1rem', transition: 'var(--transition-smooth)'
                }}
                onMouseOver={(e) => e.currentTarget.style.color = 'var(--text-primary)'}
                onMouseOut={(e) => e.currentTarget.style.color = 'var(--text-secondary)'}
            >
                <ArrowLeft size={18} /> Back to Library
            </button>

            <div className="glass-panel" style={{ display: 'flex', flexWrap: 'wrap', overflow: 'hidden' }}>
                <img
                    src={book.cover}
                    alt={`Cover of ${book.title}`}
                    style={{ width: '100%', maxWidth: '400px', objectFit: 'cover' }}
                />

                <div style={{ padding: '3rem', flex: '1 1 300px', display: 'flex', flexDirection: 'column' }}>
                    <h1 style={{ fontSize: '2.5rem', marginBottom: '1rem' }} className="text-gradient">
                        {book.title}
                    </h1>

                    <div style={{ display: 'flex', gap: '2rem', marginBottom: '2rem', flexWrap: 'wrap' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', color: 'var(--text-secondary)' }}>
                            <User size={18} color="var(--accent-primary)" />
                            <span>{book.author}</span>
                        </div>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', color: 'var(--text-secondary)' }}>
                            <Calendar size={18} color="var(--accent-primary)" />
                            <span>Published {book.published}</span>
                        </div>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', color: 'var(--text-secondary)' }}>
                            <Star size={18} color="#fbbf24" fill="#fbbf24" />
                            <span>{book.rating} / 5</span>
                        </div>
                    </div>

                    <h3 style={{ marginBottom: '1rem' }}>Synopsis</h3>
                    <p style={{ color: 'var(--text-secondary)', lineHeight: '1.7', fontSize: '1.1rem', marginBottom: '3rem' }}>
                        {book.description}
                    </p>

                    <div style={{ marginTop: 'auto' }}>
                        <button className="btn-primary" style={{ width: '100%', justifyContent: 'center', padding: '1rem' }}>
                            Read Now
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

const ContentWithLoading = withLoading(BookDetailsContent);

const BookDetails = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const [book, setBook] = useState(null);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchBookDetails = async () => {
            try {
                setIsLoading(true);
                const response = await fetch(`http://localhost:5000/books/${id}`);

                if (!response.ok) {
                    if (response.status === 404) {
                        navigate('/home', { replace: true });
                        return;
                    }
                    throw new Error('Failed to fetch book details');
                }

                const data = await response.json();
                setTimeout(() => {
                    setBook(data);
                    setIsLoading(false);
                }, 500); // Small delay for the HOC loading spinner
            } catch (err) {
                setError(err.message);
                setIsLoading(false);
            }
        };

        fetchBookDetails();
    }, [id, navigate]);

    return (
        <div style={{ paddingBottom: '4rem' }}>
            {error ? (
                <div className="glass-panel" style={{ padding: '2rem', borderLeft: '4px solid #ef4444' }}>
                    <h3 style={{ color: '#ef4444', marginBottom: '0.5rem' }}>Error Loading Book</h3>
                    <p>{error}</p>
                </div>
            ) : (
                <ContentWithLoading isLoading={isLoading} book={book} />
            )}
        </div>
    );
};

export default BookDetails;
