import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import withLoading from '../components/withLoading';
import { BookOpen } from 'lucide-react';

const BookList = ({ books }) => {
    if (books.length === 0) {
        return <div style={{ textAlign: 'center', marginTop: '3rem' }}>No books found in the database.</div>;
    }

    return (
        <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))',
            gap: '2rem',
            marginTop: '2rem'
        }}>
            {books.map(book => (
                <div key={book.id} className="glass-panel" style={{ overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
                    <img
                        src={book.cover}
                        alt={`Cover of ${book.title}`}
                        style={{ width: '100%', height: '200px', objectFit: 'cover' }}
                        loading="lazy"
                    />
                    <div style={{ padding: '1.5rem', display: 'flex', flexDirection: 'column', flex: 1 }}>
                        <h3 style={{ marginBottom: '0.5rem', fontSize: '1.25rem' }}>{book.title}</h3>
                        <p style={{ color: 'var(--text-secondary)', marginBottom: '1.5rem', flex: 1 }}>
                            By {book.author}
                        </p>
                        <Link to={`/book/${book.id}`} className="btn-primary" style={{ justifyContent: 'center' }}>
                            <BookOpen size={18} /> View Details
                        </Link>
                    </div>
                </div>
            ))}
        </div>
    );
};

const BookListWithLoading = withLoading(BookList);

const Home = () => {
    const [books, setBooks] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
       
        const fetchBooks = async () => {
            try {
                setIsLoading(true);
                const response = await fetch('http://localhost:5000/books');
                if (!response.ok) throw new Error('Failed to fetch books');
                const data = await response.json();

              
                setTimeout(() => {
                    setBooks(data);
                    setIsLoading(false);
                }, 600);
            } catch (err) {
                setError(err.message);
                setIsLoading(false);
            }
        };

        fetchBooks();
    }, []);

    return (
        <div style={{ paddingBottom: '4rem' }}>
            <header style={{ marginBottom: '3rem', marginTop: '1rem' }}>
                <h1 style={{ fontSize: '2.5rem', marginBottom: '1rem' }}>
                    Discover Your Next <span className="text-gradient">Great Read</span>
                </h1>
                <p style={{ color: 'var(--text-secondary)', fontSize: '1.1rem', maxWidth: '600px' }}>
                    Explore our hand-picked collection of acclaimed books spanning diverse genres.
                    Use the latest fetching techniques to browse seamlessly.
                </p>
            </header>

            {error ? (
                <div className="glass-panel" style={{ padding: '2rem', borderLeft: '4px solid #ef4444' }}>
                    <h3 style={{ color: '#ef4444', marginBottom: '0.5rem' }}>Error Loading Library</h3>
                    <p>{error}</p>
                </div>
            ) : (
                <BookListWithLoading isLoading={isLoading} books={books} />
            )}
        </div>
    );
};

export default Home;
