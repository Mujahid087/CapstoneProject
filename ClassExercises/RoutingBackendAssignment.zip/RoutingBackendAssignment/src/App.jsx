import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import Navigation from './components/Navigation';
import Home from './pages/Home';
import BookDetails from './pages/BookDetails';


function FadeTransition({ children }) {
  const location = useLocation();
  const [displayLocation, setDisplayLocation] = useState(location);
  const [transitionStage, setTransistionStage] = useState("fadeIn");

  useEffect(() => {
    if (location !== displayLocation) {
      setTransistionStage("fadeOut");
    }
  }, [location, displayLocation]);

  return (
    <div
      className={`${transitionStage === "fadeIn" ? "animate-fade-in" : "animate-fade-out"}`}
      onAnimationEnd={() => {
        if (transitionStage === "fadeOut") {
          setTransistionStage("fadeIn");
          setDisplayLocation(location);
        }
      }}
    >
      <Routes location={displayLocation}>
        {children}
      </Routes>
    </div>
  );
}

function App() {
  return (
    <BrowserRouter>
      <Navigation />
      <main style={{ paddingTop: '100px', minHeight: 'calc(100vh - 100px)' }}>
        <div className="container">
          <FadeTransition>
            <Route path="/home" element={<Home />} />
            <Route path="/book/:id" element={<BookDetails />} />
            <Route path="*" element={<Navigate to="/home" replace />} />
          </FadeTransition>
        </div>
      </main>
    </BrowserRouter>
  );
}

export default App;
