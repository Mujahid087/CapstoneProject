import React, { useState } from 'react';

const RenderPropsUI = ({ renderGreeting }) => {
    // Mock user state
    const [user] = useState({ name: 'Reader' });

    return (
        <div className="render-props-container">
            {renderGreeting(user.name)}
        </div>
    );
};

export default RenderPropsUI;
