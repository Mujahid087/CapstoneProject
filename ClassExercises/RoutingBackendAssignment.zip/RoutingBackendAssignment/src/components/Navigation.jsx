import React from 'react';
import { NavLink } from 'react-router-dom';
import { Library, Home } from 'lucide-react';
import RenderPropsUI from './RenderPropsUI';

const Navigation = () => {
    return (
        <nav className="glass-nav">
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                <Library color="var(--accent-primary)" size={28} />
                <h2 className="text-gradient">BookVerse</h2>
            </div>

            <div style={{ display: 'flex', gap: '2rem', alignItems: 'center' }}>
                <NavLink
                    to="/home"
                    style={({ isActive }) => ({
                        color: isActive ? 'var(--accent-primary)' : 'var(--text-primary)',
                        textDecoration: 'none',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '0.5rem',
                        fontWeight: '500',
                        transition: 'var(--transition-smooth)'
                    })}
                >
                    <Home size={20} />
                    Home
                </NavLink>

                {/* Render Props specific usage */}
                <RenderPropsUI
                    renderGreeting={(name) => (
                        <span style={{ color: 'var(--text-secondary)', fontSize: '0.95rem' }}>
                            Welcome back, <span style={{ color: 'var(--accent-secondary)' }}>{name}</span>
                        </span>
                    )}
                />
            </div>
        </nav>
    );
};

export default Navigation;
