// app.js
// this file handles fetching posts and todos from the api
// i am using the revealing module pattern here

var PostApp = (function () {

    var baseUrl = "https://jsonplaceholder.typicode.com";
    var savedTodos = [];

    // this function puts a loading text on screen
    function putLoadingMsg(where, text) {
        var box = document.getElementById(where);
        box.innerHTML = '<p class="loading-msg">' + text + '</p>';
    }

    // when something goes wrong this shows the error
    function putErrorMsg(where, message, retryCode) {
        var box = document.getElementById(where);
        box.innerHTML =
            '<div class="error-msg">' +
            message +
            '<button onclick="' + retryCode + '">Try Again</button>' +
            '</div>';
    }

    // getting the posts from the api
    function loadPosts() {
        putLoadingMsg("posts-status", "Loading posts...");
        document.getElementById("posts-list").innerHTML = "";

        fetch(baseUrl + "/posts")
            .then(function (response) {
                // see if server gave a good response
                if (!response.ok) {
                    throw new Error("Server error: " + response.status);
                }
                return response.json();
            })
            .then(function (posts) {
                document.getElementById("posts-status").innerHTML = "";

                // make sure we got proper data
                if (!Array.isArray(posts)) {
                    throw new Error("Got wrong type of data from server");
                }

                renderPosts(posts.slice(0, 15));
            })
            .catch(function (err) {
                console.error("Posts error:", err);
                putErrorMsg("posts-status", "Failed to load posts. " + err.message, "PostApp.loadPosts()");
            });
    }

    // this builds the html for each post and puts it on page
    function renderPosts(posts) {
        var container = document.getElementById("posts-list");
        var html = "";

        for (var i = 0; i < posts.length; i++) {
            html +=
                '<div class="post-card">' +
                    '<div class="post-number">Post #' + posts[i].id + '</div>' +
                    '<h3>' + posts[i].title + '</h3>' +
                    '<p>' + posts[i].body + '</p>' +
                '</div>';
        }

        container.innerHTML = html;
    }

    // getting the todos from api
    function loadTodos() {
        putLoadingMsg("todos-status", "Loading todos...");
        document.getElementById("todos-list").innerHTML = "";
        document.getElementById("filterBar").style.display = "none";
        document.getElementById("summaryBox").style.display = "none";

        fetch(baseUrl + "/todos")
            .then(function (response) {
                if (!response.ok) {
                    throw new Error("Server error: " + response.status);
                }
                return response.json();
            })
            .then(function (todos) {
                document.getElementById("todos-status").innerHTML = "";

                if (!Array.isArray(todos)) {
                    throw new Error("Got wrong type of data from server");
                }

                savedTodos = todos.slice(0, 20);
                document.getElementById("filterBar").style.display = "flex";
                showSummary();
                renderTodos(savedTodos);
            })
            .catch(function (err) {
                console.error("Todos error:", err);
                putErrorMsg("todos-status", "Failed to load todos. " + err.message, "PostApp.loadTodos()");
            });
    }

    // builds html for each todo item
    function renderTodos(todos) {
        var container = document.getElementById("todos-list");
        var html = "";

        for (var i = 0; i < todos.length; i++) {
            var todo = todos[i];
            var st = todo.completed ? "done" : "pending";
            var icon = todo.completed ? "✓" : "○";
            var tag = todo.completed ? "Done" : "Pending";

            html +=
                '<div class="todo-row">' +
                    '<span class="todo-check ' + st + '">' + icon + '</span>' +
                    '<span class="todo-text ' + (todo.completed ? "done" : "") + '">' +
                        todo.title +
                    '</span>' +
                    '<span class="todo-label ' + st + '">' + tag + '</span>' +
                '</div>';
        }

        container.innerHTML = html;
    }

    // counting done and pending and showing it
    function showSummary() {
        var doneCount = 0;
        for (var i = 0; i < savedTodos.length; i++) {
            if (savedTodos[i].completed) {
                doneCount++;
            }
        }

        document.getElementById("countAll").textContent = savedTodos.length;
        document.getElementById("countDone").textContent = doneCount;
        document.getElementById("countLeft").textContent = savedTodos.length - doneCount;
        document.getElementById("summaryBox").style.display = "flex";
    }

    // handles the filter buttons for todos
    function filterTodos(type, btnElement) {
        var btns = document.getElementById("filterBar").querySelectorAll("button");
        for (var i = 0; i < btns.length; i++) {
            btns[i].className = "";
        }
        btnElement.className = "active";

        var result = [];
        if (type === "all") {
            result = savedTodos;
        } else if (type === "done") {
            for (var j = 0; j < savedTodos.length; j++) {
                if (savedTodos[j].completed) result.push(savedTodos[j]);
            }
        } else {
            for (var k = 0; k < savedTodos.length; k++) {
                if (!savedTodos[k].completed) result.push(savedTodos[k]);
            }
        }

        renderTodos(result);
    }

    // only exposing the functions we need outside
    return {
        loadPosts: loadPosts,
        loadTodos: loadTodos,
        filterTodos: filterTodos
    };

})();
