# Fetch API Assignment

## Approach

My approach was to build a simple web page that fetches data from the JSONPlaceholder API and shows it on screen. I divided the work into small steps:

1. First I created the HTML structure with sections for posts and todos.
2. Then I added CSS to make it look clean and readable.
3. Next I wrote JavaScript to fetch data from the API using the Fetch API.
4. I added error handling so that if something goes wrong, the user sees a proper message with a retry option.
5. Finally I refactored all the JavaScript code into the Revealing Module Pattern to keep it organized.

## Code Implementation

### Files
- **index.html** — Contains the page structure with headings, buttons, and containers for posts and todos.
- **styles.css** — Simple styling with a light color scheme, card layout for posts, and row layout for todos.
- **app.js** — All the JavaScript logic wrapped inside a Revealing Module Pattern (IIFE).

### How It Works
- When the user clicks "Show Posts", the app calls `fetch()` on the `/posts` endpoint, gets JSON data, and creates post cards dynamically.
- When the user clicks "Show Todos", it fetches from `/todos`, displays each todo with its status (Done/Pending), and shows a summary with counts.
- Filter buttons let the user view All, Done, or Not Done todos.
- If the API call fails (no internet, server error, bad data), an error message is shown with a "Try Again" button.

### Design Pattern Used
I used the **Revealing Module Pattern**. The entire app is wrapped in an IIFE (Immediately Invoked Function Expression) called `BlogApp`. Functions like `displayPosts()`, `showLoading()`, and `showError()` are kept private inside the module. Only `fetchPosts`, `fetchTodos`, and `filterTodos` are returned and made public. This prevents global scope pollution and keeps the code modular.

## Challenges Faced

1. **Error Handling** — I had to handle different types of errors separately. A network error (no internet) gives a `TypeError`, while a server error (like 500) needs checking `response.ok`. I used try-catch and conditional checks for both.
2. **Filtering Todos** — To implement filtering without re-fetching data, I had to store the todos in a variable (`allTodos`) and then filter from that stored array each time the user clicks a filter button.
3. **DOM Updates** — Building HTML strings manually with string concatenation was a bit tedious, but it keeps the code simple without needing any template library.

## Reflection

This assignment helped me understand several key concepts:

- **Fetch API** is much cleaner than the older XMLHttpRequest for making HTTP calls. Using `.then()` chains makes the code easy to follow.
- **Error handling** is very important when working with APIs because many things can go wrong (no internet, server down, wrong data format). Showing user-friendly messages instead of crashing silently makes a big difference.
- **The Revealing Module Pattern** taught me how to organize JavaScript code properly. By keeping helper functions private and only exposing what is needed, the code becomes easier to maintain and less likely to conflict with other scripts.
- **DOM manipulation** using `innerHTML` and `getElementById` is straightforward for simple apps like this. I learned how to dynamically build HTML from API data.

Overall, this assignment gave me practical experience with real API calls, handling real-world errors, and writing structured JavaScript code.

## APIs Used
- Posts: https://jsonplaceholder.typicode.com/posts
- Todos: https://jsonplaceholder.typicode.com/todos
- Documentation: https://jsonplaceholder.typicode.com/
