const multer = require("multer");
const path = require("path");
const { uploadsDir } = require("../config/paths");
const sanitizeFileName = require("../utils/sanitizeFileName");

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => {
    cb(null, uploadsDir);
  },
  filename: (_req, file, cb) => {
    cb(null, sanitizeFileName(file.originalname));
  }
});

const upload = multer({
  storage,
  limits: {
    fileSize: 10 * 1024 * 1024
  },
  fileFilter: (_req, file, cb) => {
    const isPdfMimeType = file.mimetype === "application/pdf";
    const isPdfExtension = path.extname(file.originalname).toLowerCase() === ".pdf";

    if (isPdfMimeType && isPdfExtension) {
      cb(null, true);
      return;
    }

    cb(new Error("Only PDF files are allowed."));
  }
});

module.exports = upload;
