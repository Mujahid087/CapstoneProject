const multer = require("multer");

const errorHandler = (err, _req, res, _next) => {
  if (err instanceof multer.MulterError) {
    res.status(400).send(err.message);
    return;
  }

  if (err) {
    res.status(400).send(err.message);
    return;
  }

  res.status(500).send("Internal server error.");
};

module.exports = errorHandler;
