const { publicDir } = require("../config/paths");

const getHomePage = (_req, res) => {
  res.sendFile("index.html", { root: publicDir });
};

const uploadMaterial = (req, res) => {
  if (!req.file) {
    res.status(400).send("Please upload a PDF file.");
    return;
  }

  res.send(`File uploaded successfully: ${req.file.filename}`);
};

module.exports = {
  getHomePage,
  uploadMaterial
};
