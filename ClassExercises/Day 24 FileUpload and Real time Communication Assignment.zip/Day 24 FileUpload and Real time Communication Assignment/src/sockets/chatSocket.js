const registerChatSocket = (io) => {
  io.on("connection", (socket) => {
    socket.on("chat message", (payload) => {
      const trimmedUser = String(payload?.user || "Anonymous").trim() || "Anonymous";
      const trimmedMessage = String(payload?.message || "").trim();

      if (!trimmedMessage) {
        return;
      }

      io.emit("chat message", {
        user: trimmedUser,
        message: trimmedMessage,
        timestamp: new Date().toISOString()
      });
    });
  });
};

module.exports = registerChatSocket;
