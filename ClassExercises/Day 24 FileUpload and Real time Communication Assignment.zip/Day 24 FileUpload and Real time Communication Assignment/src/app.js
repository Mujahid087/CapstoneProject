const express = require("express");
const fs = require("fs");
const path = require("path");
const materialRoutes = require("./routes/materialRoutes");
const errorHandler = require("./middleware/errorHandler");
const { publicDir, uploadsDir } = require("./config/paths");

const app = express();

fs.mkdirSync(uploadsDir, { recursive: true });

app.use(express.json());
app.use(express.static(publicDir));
app.use(
  "/materials",
  express.static(uploadsDir, {
    setHeaders: (res, filePath) => {
      res.setHeader("Content-Disposition", `attachment; filename="${path.basename(filePath)}"`);
    }
  })
);

app.use("/", materialRoutes);
app.use(errorHandler);

module.exports = app;
