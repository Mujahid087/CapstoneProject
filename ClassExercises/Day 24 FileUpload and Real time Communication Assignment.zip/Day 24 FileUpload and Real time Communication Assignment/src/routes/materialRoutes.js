const express = require("express");
const { getHomePage, uploadMaterial } = require("../controllers/uploadController");
const upload = require("../middleware/uploadMiddleware");

const router = express.Router();

router.get("/", getHomePage);
router.post("/upload", upload.single("file"), uploadMaterial);

module.exports = router;
