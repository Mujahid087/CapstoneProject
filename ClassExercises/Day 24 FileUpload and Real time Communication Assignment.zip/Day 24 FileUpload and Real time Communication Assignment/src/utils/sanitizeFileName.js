const path = require("path");

const sanitizeFileName = (fileName) => {
  const extension = path.extname(fileName).toLowerCase();
  const baseName = path.basename(fileName, extension);
  const safeBaseName = baseName
    .replace(/[^a-zA-Z0-9_-]/g, "_")
    .replace(/_+/g, "_")
    .replace(/^_+|_+$/g, "") || "file";

  return `${safeBaseName}${extension}`;
};

module.exports = sanitizeFileName;
