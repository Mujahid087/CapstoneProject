import { Contact, ContactManager } from './ContactManager';

const contactManager = new ContactManager();


console.log("--- Adding Contacts ---");
const contact1: Contact = { id: 1, name: "Alice Johnson", email: "alice@example.com", phone: "123-456-7890" };
const contact2: Contact = { id: 2, name: "Bob Smith", email: "bob@example.com", phone: "987-654-3210" };

contactManager.addContact(contact1);
contactManager.addContact(contact2);


console.log("\n--- Viewing Contacts ---");
const contacts = contactManager.viewContacts();
console.log(contacts);

console.log("\n--- Modifying Contact ---");
contactManager.modifyContact(1, { phone: "111-222-3333" });
console.log("After modification:");
console.log(contactManager.viewContacts());


console.log("\n--- Deleting Contact ---");
contactManager.deleteContact(2);
console.log("After deletion:");
console.log(contactManager.viewContacts());


console.log("\n--- Error Handling Scenarios ---");
contactManager.modifyContact(99, { name: "Non-existent" }); 
contactManager.deleteContact(99); 
