interface Contact {
    id: number;
    name: string;
    email: string;
    phone: string;
}
declare class ContactManager {
    private contacts;
    addContact(contact: Contact): void;
    viewContacts(): Contact[];
    modifyContact(id: number, updatedContact: Partial<Contact>): void;
    deleteContact(id: number): void;
}
export { Contact, ContactManager };
