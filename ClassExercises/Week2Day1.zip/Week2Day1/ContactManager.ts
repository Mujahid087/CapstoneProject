interface Contact {
    id: number;
    name: string;
    email: string;
    phone: string;
}

class ContactManager {
    private contacts: Contact[] = [];

    addContact(contact: Contact): void {
        const existingContact = this.contacts.find(c => c.id === contact.id);
        if (existingContact) {
            console.error(`Error: Contact with ID ${contact.id} already exists.`);
            return;
        }
        this.contacts.push(contact);
        console.log(`Success: Contact '${contact.name}' added successfully.`);
    }

    viewContacts(): Contact[] {
        return this.contacts;
    }

    modifyContact(id: number, updatedContact: Partial<Contact>): void {
        const contactIndex = this.contacts.findIndex(c => c.id === id);
        if (contactIndex === -1) {
            console.error(`Error: Contact with ID ${id} not found.`);
            return;
        }

        this.contacts[contactIndex] = { ...this.contacts[contactIndex], ...updatedContact } as Contact;
        console.log(`Success: Contact with ID ${id} modified successfully.`);
    }

    deleteContact(id: number): void {
        const contactIndex = this.contacts.findIndex(c => c.id === id);
        if (contactIndex === -1) {
            console.error(`Error: Contact with ID ${id} not found.`);
            return;
        }

        const deletedContactName = this.contacts[contactIndex].name;
        this.contacts.splice(contactIndex, 1);
        console.log(`Success: Contact '${deletedContactName}' deleted successfully.`);
    }
}

export { Contact, ContactManager };
