"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ContactManager = void 0;
class ContactManager {
    constructor() {
        this.contacts = [];
    }
    addContact(contact) {
        const existingContact = this.contacts.find(c => c.id === contact.id);
        if (existingContact) {
            console.error(`Error: Contact with ID ${contact.id} already exists.`);
            return;
        }
        this.contacts.push(contact);
        console.log(`Success: Contact '${contact.name}' added successfully.`);
    }
    viewContacts() {
        return this.contacts;
    }
    modifyContact(id, updatedContact) {
        const contactIndex = this.contacts.findIndex(c => c.id === id);
        if (contactIndex === -1) {
            console.error(`Error: Contact with ID ${id} not found.`);
            return;
        }
        this.contacts[contactIndex] = Object.assign(Object.assign({}, this.contacts[contactIndex]), updatedContact);
        console.log(`Success: Contact with ID ${id} modified successfully.`);
    }
    deleteContact(id) {
        const contactIndex = this.contacts.findIndex(c => c.id === id);
        if (contactIndex === -1) {
            console.error(`Error: Contact with ID ${id} not found.`);
            return;
        }
        const deletedContactName = this.contacts[contactIndex].name;
        this.contacts.splice(contactIndex, 1);
        console.log(`Success: Contact '${deletedContactName}' deleted successfully.`);
    }
}
exports.ContactManager = ContactManager;
