const fs = require("fs").promises;

async function manageFile() {
  const userInput = "Node.js is awesome!";
  const fileName = "feedback.txt";

  await fs.writeFile(fileName, userInput, "utf-8");
  console.log("Data written successfully.");

  console.log("Reading file...");
  const data = await fs.readFile(fileName, "utf-8");
  console.log(data);
}

manageFile();
