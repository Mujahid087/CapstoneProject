const EventEmitter = require("events");

const emitter = new EventEmitter();

emitter.on("userLoggedIn", (username) => {
  console.log(`User ${username} logged in.`);
});

emitter.on("userLoggedOut", (username) => {
  console.log(`User ${username} logged out.`);
});

emitter.on("sessionExpired", (username) => {
  console.log(`Session expired for ${username}.`);
});

emitter.emit("userLoggedIn", "John");
emitter.emit("userLoggedOut", "John");

setTimeout(() => {
  emitter.emit("sessionExpired", "John");
}, 5000);
