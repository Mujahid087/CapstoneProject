const http = require("http");
const fs = require("fs").promises;
const path = require("path");

const server = http.createServer(async (req, res) => {
  if (req.url === "/") {
    try {
      const content = await fs.readFile(
        path.join(__dirname, "index.html"),
        "utf-8"
      );
      res.writeHead(200, { "Content-Type": "text/html" });
      res.end(content);
    } catch {
      res.writeHead(200, { "Content-Type": "text/html" });
      res.end("<h1>Hello from Node.js Server</h1>");
    }
  } else if (req.url === "/about") {
    try {
      const content = await fs.readFile(
        path.join(__dirname, "about.html"),
        "utf-8"
      );
      res.writeHead(200, { "Content-Type": "text/html" });
      res.end(content);
    } catch {
      res.writeHead(200, { "Content-Type": "text/html" });
      res.end("<h1>About Page</h1>");
    }
  } else {
    res.writeHead(404, { "Content-Type": "text/html" });
    res.end("<h1>404 - Page Not Found</h1>");
  }
});

const PORT = 3000;

server.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
